# Reviewing and committing the goal-set geometry study

This is an additive research contribution based on
`d07cd7878cb40ecbd9e1004ef7db6794eb08d1df`. Existing tracked files, teammate
branches and the vendored upstream source were not changed. No commit or push
was made. Review the new files before applying them to a newer team checkout.

## Start here

1. Read `docs/goal_quotient_study.md` for results, interpretation and limits.
2. Open `code/notebooks/goal_quotient_study.ipynb` for executed analysis,
   independently checked physical labels and figures.
3. Read `docs/goal_quotient_prior_art.md` for the nine-source comparison and
   why this is a controlled diagnostic contribution, not a new projection
   principle or a claimed planning state of the art.
4. Follow `docs/goal_quotient_reproduction.md` to rerun the lightweight analysis
   or the complete simulator/model experiment. The frozen decisions are in
   `docs/goal_quotient_protocol.md`.

## Proposed files

- `code/jepa_planning/goal_quotient.py`
- `code/experiments/run_pusht_goal_quotient.py`
- `code/experiments/rescore_pusht_patch_quotient.py`
- `code/experiments/summarize_pusht_goal_quotient.py`
- Four corresponding `code/tests/test_*quotient.py` files
- `code/notebooks/goal_quotient_study.ipynb`
- The five `docs/goal_quotient_*.md` guides and reports, including this guide
- `docs/goal_quotient_results/`: small tables, manifests and synthetic states
- `docs/figures/goal_quotient/`: five figures
- `requirements/goal_quotient_cpu.freeze.txt`

The companion ZIP contains only these new files, under repository-relative
paths. Its `BUNDLE_SHA256.json` gives per-file SHA-256 checksums. Extract into
a temporary directory, inspect the file list, then copy the selected additions
into a clean team worktree. Do not extract over conflicting files without
reviewing them. This bundle does not include a virtual environment, model
weights, large latent caches, the original repository or private notes.

## Verification performed

The repository test suite passed **171 tests**. All eight notebook code cells
executed successfully with real captured outputs, and the five figures were
visually inspected. Kernel startup was restricted in the isolated environment;
the precise in-process IPython validation method is documented in the
reproduction guide and notebook metadata. Portable state banks independently
reproduce physical error, regret and success for all 1,000 final decisions.

With a compatible environment, run:

```bash
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 .venv/bin/python -m pytest code/tests -q
```

The useful result is that fitting away more nuisance variation did not improve
the primary held-out action-selection metric. Eight-photo averaging remains a
strong positive control. Do not present the projection as a demonstrated gain,
or the crossed-zero interval as proof of equivalence or a definitive loss.
