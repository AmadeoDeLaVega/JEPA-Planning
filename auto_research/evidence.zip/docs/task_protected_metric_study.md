# Task protected nuisance attenuation study

## Finding and decision

**Protecting local task distances while suppressing nuisance variation did not improve the primary development action choices.** Across all 24 predetermined PushT development tasks, the predicted endpoint protected metric and the eight photo prototype had identical selected indices for every calibration head. Mean paired physical regret reduction was **0.000**, with the conditional hierarchical interval **[0.000, 0.000]**, zero of three positive banks, and zero gain in each of the three independent calibration fits.

The frozen development screen therefore **failed**. The reserved 100 task locked evaluation was **not generated or opened**. A degenerate development interval here records identical observed decisions; it does not establish population equivalence. The preexisting quotient study and its 37 deliverable files remain unchanged. This separate study changes the target generation protocol, so its regret levels are not a numerical replication of the old tables.

The original proposal's contrastive adapter was a promising **secondary development control**, with predicted regret reduction **2.014 [0.602, 3.448]** and positive means in three development banks. It does not replace the failed primary method, turn development into a held out result, or justify opening the primary study's locked evaluation. Confirming that adapter finding would require a separately frozen study on fresh tasks.

## Question and method

The question was whether nuisance attenuation becomes useful when it is explicitly prevented from erasing nearby task distinctions. The full rank shared channel metric is `W = I - U diag(a) U.T`, with at most 32 nuisance directions, `0 <= a <= 0.90`, and every training target prototype pair retaining at least 90% of its original squared distance. The objective maximizes removed within target nuisance energy. HiGHS solves the bounded linear program in float64. Every feature retains its 256 fixed spatial patches and 384 channels. The metric changes endpoint scoring only; world model rollouts always use original frozen features.

The cost is the mean over goal photographs and patches of `delta.T W delta / 384`. W has eigenvalues at least 0.10. These are finite training distance guarantees, not guarantees about candidate rankings, physical distances, unseen poses, or interventions beyond those sampled. All 8,128 pairs of the 128 training target groups enter each fit. No physical coordinate regression target enters the optimizer.

This is **structured task supervision**, not fully unsupervised learning: simulator interventions define same target groups and nearby distinct targets. Constrained Mahalanobis learning and equivalence supervision are established ideas. The original proposal is credited for equivalent and different target labels and its learned rank 32 adapter. The possible contribution of this follow on is the controlled test and its negative decision result, not a new optimizer or a state of the art claim. Prior sources and distinctions are recorded in [the original plan](goal_quotient_next_experiment.md#sources-and-limits-on-novelty).

## Frozen design and data

- Three calibration draws, seeds 20264001 through 20264003: each has 32 families, four target groups per family, and eight photographs per group, for 1,024 images per draw.
- One independent image validation draw, seed 20264011: eight families, four groups, 16 photographs per group, for 512 images. The first eight make prototypes and the last eight audit nuisance variation.
- Three development banks, seeds 20264101 through 20264103: eight tasks each, 64 fixed candidates per task. All 24 tasks were retained.
- The locked seeds 20264201 through 20264210 remain closed after the failed screen. There are no new locked or closed loop outcomes for this metric.
- Each physical target is the endpoint with largest object displacement among 16 independently sampled reference chunks, each with five elementary controls. Only after freezing that goal are 64 new candidate chunks generated from separate named streams. Reference actions are never inserted. Oracle success was available in the candidate banks of all 24 development tasks; the three exactly stationary reference targets were retained.
- Each local calibration family contains the base target and exactly one seeded signed x shift of 12 pixels, y shift of 12 pixels, and rotation of 0.10 radians. All family photographs use agent positions safe at every family target. Group identities, not physical distances, are the fit labels.

Before any official data, a [geometry clarification](task_protected_metric_validity_amendment.json) required every base and local object polygon to clear arena walls. It fixes a maximum of 100 whole family proposals, with every attempt using its saved named stream offset. Rejections occur before features or ranking candidate generation and cannot depend on candidate outcomes or learned costs. The study therefore concerns **wall conditioned, reference generated targets**, not arbitrary wall contact targets. No whole family reference proposal was rejected in the executed calibration, validation, or development sets.

Ranking photographs have a disclosed safety distribution difference. The main eight and first four audit agents are sampled safe for the base target. The last four audit agents are also safe at all six signed interventions and provide exactly matched diagnostic baselines. Thus main versus audit agreement measures transfer under this safety conditioning difference, not an independent identically distributed repeat. The image validation families match all 16 agents across all four targets as planned.

## Controls and fitting

Every method scores the same cached true and predicted endpoints and the same photographs. Controls include the exact 0.90 I scaling, same basis equal removed training nuisance energy, same trace attenuation, random basis at the protected spectrum, genuinely shuffled image group assignments, seeded random rank 32 compression, and the proposal's contrastive adapter. Uniform scaling is not learned invariance.

All nine adapter fits completed 1,000 Adam updates, batch 16, seven different target negatives, learning rate 0.001, and Frobenius normalization after each update. The global temperature multiplier 0.1 was chosen from 0.1, 1, and 10 by mean image validation loss across the three calibration fits, before ranking outcomes. The corresponding means were 0.003358, 0.043077, and 0.346177. Costs use `W_L = 384 L.T L / trace(L.T L)` with the same /384 patch convention, not an additional division by rank or channel count.

The methods have the same 1,024 image budget per calibration draw and access to the same task group labels. They do not have equal fitting compute or equal local negative exposure: the LP constrains every target pair, while the adapter samples seven different targets per anchor. Adapter loss curves are preserved for all temperatures. Low contrastive loss is not itself a control result, and variable final window losses do not establish precise optimizer convergence.

All three protected fits had rank 32 and minimum training retention 0.90. The worst exported constraint residual was 2.84e-14 in original energy units, with no target prototype collisions. Selected models, all nine adapter candidates, and their source and cache hashes are retained.

## Independent geometry screen

The nuisance quantity is the equal group mean energy of all unordered pairs of each target's eight audit photographs. Local target energy uses the main eight photograph prototypes for base versus x, y, and angle, giving 24 local pairs per fit. The ratio screen requires at least 10% reduction versus identity, median local retention at least 90%, and its tenth percentile at least 80%, separately for every calibrated metric.

| Calibration seed | Ratio reduction | Median local retention | Tenth percentile | Geometry screen |
|---|---:|---:|---:|---|
| 20264001 | 14.43% | 95.37% | 94.04% | pass |
| 20264002 | 14.30% | 96.98% | 95.61% | pass |
| 20264003 | 17.80% | 97.48% | 96.00% | pass |

The metric passed this image geometry screen, including the separately exported axis diagnostics. It preserved local signal better than equal nuisance energy attenuation in this validation set. That did **not** produce a physical selection gain. Raw energy reductions alone are not counted as invariance. Adapter ratio gains also involve substantial local signal amplification under its trace normalized rank 32 metric, not merely nuisance suppression.

![Independent geometry screen](task_protected_metric_results/figures/validation_geometry.png)

## Development outcomes only

Physical error is `sqrt(position_error**2 + (50 * wrapped_angle_error)**2)`; regret subtracts the best available error in the same 64 candidate bank. Success requires position error below 20 pixels and angle error below 20 degrees. The primary observation averages each task's physical outcome over the three separately calibrated heads. It is not a score ensemble and the heads are not extra tasks.

| Method | Predicted regret | Actual encoded regret | Predicted success | Development gain versus prototype |
|---|---:|---:|---:|---:|
| prototype | 3.346 | 2.790 | 87.5% | reference |
| protected | 3.346 | 2.790 | 87.5% | +0.000 [+0.000, +0.000] |
| equal_energy | 3.341 | 2.607 | 87.5% | +0.004 [+0.000, +0.017] |
| same_trace | 3.346 | 2.790 | 87.5% | +0.000 [+0.000, +0.000] |
| random_spectrum | 3.346 | 2.790 | 87.5% | +0.000 [+0.000, +0.000] |
| shuffled | 3.346 | 2.790 | 87.5% | +0.000 [+0.000, +0.000] |
| adapter | 1.332 | 1.149 | 97.2% | +2.014 [+0.602, +3.448] |
| random_rank32 | 3.450 | 2.421 | 88.9% | -0.105 [-1.273, +0.937] |
| isotropic | 3.346 | 2.790 | 87.5% | +0.000 [+0.000, +0.000] |

Intervals use 10,000 paired hierarchical draws, resampling the three development banks and then tasks inside each sampled bank, with all sources, methods, photo sets and heads kept together. The seed is 20264901. These intervals are exploratory development descriptions, conditional on these three calibration draws; three fits do not estimate broad training population uncertainty. Secondary intervals are not multiplicity adjusted.

Protected changed no predicted main photo choices across the 72 task and calibration combinations. It changed three actual encoded choices without changing their physical errors. Mean predicted selected error stayed 9.183 with success 87.5%, and mean actual encoded regret stayed 2.790. This is not a predominantly rollout transfer failure: there was no regret gain with exact encoded endpoints either. The protected versus equal nuisance energy predicted gain was -0.004, so these outcomes do not support attributing a decision gain to the protection constraints.

![Development effects](task_protected_metric_results/figures/development_effects.png)

## Mechanistic diagnostics and limits

The exports retain every selected index and cost and physical error vector for both feature sources, both photograph sets, all heads and controls, and the balanced one and four photo prototype sensitivities. They also retain exact rollout score discrepancy terms. For `delta = actual - mean_goal` and `e = predicted - actual`, the difference is the patch mean of `2 delta.T W e + e.T W e`, divided by 384. The goal photograph variance cancels. The largest numerical mismatch across exported candidates was 1.31e-13. Strict pairwise order reversals and transitions into or out of ties are exported separately.

These diagnostics separate metric geometry from rollout induced score distortion algebraically. They do not identify causal uncertainty or show that whitening prediction errors would improve planning. Global and best quarter rank correlations, signed x and y and rotation interventions at four matched agents, actual versus predicted agreement, and photograph transfer are available separately. None is substituted for the fixed primary decision endpoint.

![Rollout diagnostics](task_protected_metric_results/figures/rollout_diagnostics.png)

The one step action bank probe does not establish closed loop performance, long horizon preparation, CEM robustness, broad task generality, or equivalence. No threshold, attenuation bound, head, temperature grid, blend, task count, or primary winner was changed after development outcomes. The adapter control deserves a fresh independently evaluated protocol, not a retrospective change to this one.

## Verification and resources

The predata suite passed 304 tests and the later complete repository suite passed 340 tests. Gate evidence verifies the complete 5,472 row selection grid, 175,104 finite candidate vector rows, 288 full isotropic score rankings, six reloaded LP metrics with valid PSD floors and bounds, 984 independently reset safe development states, and the frozen 18 source and 35 model or registry files. The fixed screen failed only its development effect condition; every correctness and geometry condition passed.

Available historical raw PushT banks and 13 reconstructed historical task definition banks were compared with the new states and object targets. Historical sources were byte checked against revision 80d45ed2, but regenerated simulator outputs are explicitly **not asserted to equal unavailable historical raw bytes**. Recorded pusht_noise training scenes were not used to train this metric. Meta World has a different simulator and state and action domain. Model dependent historical executed planner states were unavailable; distinct requested task definitions, not unsupported byte identity claims, establish the no reused synthetic task scope. One fully clipped action chunk matched an old chunk at a different initial scene; the new object and agent were 122.95 and 128.83 pixels away, respectively. This action only overlap is recorded and is not duplicate task data.

Official follow on datasets used 17,920 elementary controls: 7,680 calibration, 640 validation, and 9,600 development. Rejected whole family reference controls were zero. The original 57,920 control estimate included the 40,000 locked controls that were never run. Historical simulator reconstruction and retired engineering probes are separate preparation costs inside the same wall time and resource ceiling, not additional independent experiment samples. The executed datasets contain 6,104 encoded images and 1,536 predicted endpoints, not the full proposed 16,604 and 7,936.

Calibration generation took 243.2 seconds, validation generation 37.3 seconds, all fits 411.7 seconds, validation scoring 26.6 seconds, development generation 341.0 seconds, and development scoring 242.9 seconds. Fit peak resident memory was about 1.33 GiB; the observed fitting storage peak was about 1.97 GiB before development. Development scoring observed about 2.96 GiB of study storage and 0.73 GiB process peak memory. All jobs used at most four CPU threads. The overall initial study ceiling was four wall clock hours, 8 GiB resident memory, and 16 GiB new storage; per component resource and time records remain in the audited manifests. Scoring runtime tables include scoring and export work and are not isolated model inference benchmarks.

## Files and reproduction

- [Executed notebook](../code/notebooks/task_protected_metric_study.ipynb) regenerates the tables and five figures from portable files without a checkpoint, raw videos, Jupyter kernel socket, or locked data.
- [Portable bundle guide](task_protected_metric_results/README.md) describes the selected model files, every adapter candidate, small state and reference banks, split and gate evidence, full score vectors, and hashes.
- [Fixed failed gate](task_protected_metric_results/gate.json) preserves the decision and all per head geometry values. No held out test score exists.
- The original [plan](goal_quotient_next_experiment.md), [protocol](task_protected_metric_protocol.json), [geometry definition](task_protected_metric_gate_geometry.json), and [predata validity clarification](task_protected_metric_validity_amendment.json) retain their original bytes.

Saved terminal seven dimensional states verify physical endpoint errors, but do not fully determine candidate images: resetting the environment advances physics and does not restore object velocity. To reconstruct candidate images, replay the saved full action sequence from the saved initial state with the recorded simulator and action normalization. Goal photographs are reset verified static states and can be rerendered from their saved states. Frozen generation entry points intentionally enforce the recorded study deadline; later expensive reruns require a new explicit resource plan and fresh output rather than overwriting this study. The portable notebook remains runnable after that deadline.

No existing tracked files or previous study artifacts were edited, and no commit, push, or external publication was made for this follow on.
