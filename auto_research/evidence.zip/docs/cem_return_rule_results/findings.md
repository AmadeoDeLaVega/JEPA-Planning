# CEM return rule: evaluated incumbent versus final elite mean

The frozen one-step confirmation passes all prespecified effect requirements. This is an established iCEM-style return-rule ablation in this
project's reduced-budget wrapper, not a novel optimizer or a full DINO-WM
closed-loop benchmark replication.

## Complete frozen physical result

The 100 locked tasks are ten banks of ten, not 130 planning evaluations treated
as independent outcomes. All tasks, ties and zero-displacement targets remain.

- Mean object error: A final mean **24.8187**, B evaluated
  incumbent **19.8428** pixels-equivalent.
- Paired A−B improvement: **4.9758**,
  hierarchical paired 95% interval **[3.2411, 6.9272]**.
- Positive bank means: **10/10**. Improved / tied within
  1e−6 / worsened tasks: **59 / 38 / 3**.
- Success: A 42/100, B 53/100. Success
  requires position <20 pixels and angular error <20 degrees.
- Development was separate: 12 tasks, three banks; mean improvement
  4.8269, positive banks 3/3.
  The frozen development gate passed before the 100 tasks were opened.

Object error is sqrt(position_pixels² + (50×wrapped_angle_radians)²). The primary
test was frozen as mean improvement ≥0.5, hierarchical 95% lower >0 and positive
means in ≥8/10 banks. This is a one-observation, one-model-step/five-relative-
control experiment, not a claim about longer horizons, other tasks or closed-loop
success. The reference target was independently selected before CEM from 16
reachable chunks; zero-displacement targets were retained.

## A lower model cost is not itself the physical result

The incumbent's imagined cost cannot exceed the explicitly scored final mean's
cost by construction. It is the independent physical comparison above, not that
inequality, that tests usefulness. Among all 100 locked tasks:

- B improves predicted main-prototype cost but worsens actual encoded visual
  cost on **18** tasks. This is a finite
  model/actual-image preference reversal for the two fixed returns.
- B improves actual encoded visual cost but worsens physical object error on
  **3** tasks. This is a finite
  visual-metric/object preference disagreement, not proof of a causal mechanism.
- There are **5** identical A/B action returns.
  Exact visual-cost ties and all raw gains are retained in the portable data.

The independent eight-photo audit reverses the predicted preference for the
fixed two returns on **6** tasks. This
is **fixed-head rescoring**, not full CEM replanning photo stability. No audit
photo affected the return, candidate population, task acceptance or primary gate.
These diagnostics are descriptive, finite-decision comparisons and were never
test-time selection signals. They cannot separate every model, rendering,
metric or contact effect or certify infinitesimal derivatives.

## Identical planning budget and certificates

Both arms use the same two iterations of 64 CEM candidates/eight elites, same
normal draws, mean inclusion, clipping ±2 and std updates. Every updated elite
mean is explicitly scored, adding two queries. A returns the last mean; B is the
first chronological minimum among all 130 evaluations. The incumbent never
changes the population update. Every task's sampled minimum and both actual
returned costs are stored separately and checked against saved actions.

- Per scientific task: **130 candidate queries per arm**, executed once as one
  shared stream, not 260 executed queries; 18 predictor microbatches at batch 8.
- Confirmation: **13000** shared planning queries.
  Development: 1560.
- The retired engineering task alone adds 132 diagnostic queries for exact full
  replay and the two cost rescores. No scientific task gets these extra queries.
- Per task: 16 goal images, one start and two returned endpoint images encoded
  (19 frames); only two physical five-control return heads are executed. The
  eight audit photos are scored in the existing forward calls, adding zero
  planning queries and zero physical heads.
- Cumulative model-run time: 1586.12s;
  peak phase RSS 0.975 GiB.
  The 45-minute/four-thread/8-GiB/500-MB study ceilings and global deadline were
  checked. Runtime is shared-stream runtime, not measured independent-arm speed.

## Independence and integrity

The pre-outcome freeze SHA-256 is `005e87b30896d34cf9f91ac1846c25054148306b8b22c138d6555a600923e59d`. Scientific source,
checkpoint and actual encoder bytes match that freeze; all per-task saved
action/cost/outcome hashes and physical-error recomputations passed. The
retired numerical preflight passed all 36 tests; exact engineering replay passed.

An additional post-completion task-aware equality audit checks same-cohort and
cross-cohort exact identities, allowing repeated states/poses within a task and
logging shared actions at different starts rather than censoring tasks. Scope:
{"cem_development": 12, "cem_engineering": 1, "cem_locked": 100, "protected_identity_metadata": 128}. It found
**0** shared state/pose
identities across distinct task labels, and logged
1 shared action identities.
See `identity_audit.json` for exact counts and sources. No physical-result
filtering or resampling occurred. Exact equality does not exclude near-duplicates;
missing original historical raw banks are not declared byte-verified.

An older phase-only leakage checker did not by itself exclude reuse between
distinct tasks in the same phase. This independent task-label audit addresses
that audit gap without changing frozen source/data or treating it as evidence
that reuse actually occurred.

## Prior art and what is useful

[iCEM, Section 3.3 and Appendix E.3](https://proceedings.mlr.press/v155/pinneri21a/pinneri21a.pdf)
already chooses the best evaluated sequence rather than an unscored mean and
adds the mean as a candidate. This study does not claim that return principle.
[Grad+CEM](https://proceedings.mlr.press/v120/bharadhwaj20a.html) already combines
sampling and action gradients. [DINO-WM Appendix A.5](https://arxiv.org/html/2411.04983v2#A5)
already compares gradient planning and CEM, with stronger CEM results in its
setting. None of those full benchmark tables are reproduced by this probe.

The contribution here is the frozen, identical-evaluation local ablation,
honest actual-returned-cost certificates and physical-versus-visual finite-
preference audit on new tasks. Preserve the separate negative near-hold gradient
audit and protected-metric findings; they were not tuning data for this method.

## Portable files and reproduction

- `summary.json`, `task_metadata.json`, `task_arrays.npz`: complete small scalar,
  action/state/cost results, including development separately from confirmation.
- `freeze_manifest.json`, `data_provenance.json`, `identity_audit.json`,
  `diagnostic_spec.json`: identities, exact sources, limits and analysis definitions.
- `../../code/notebooks/cem_return_rule_study.ipynb`: actually executed notebook;
  reads only this portable bundle, without models or simulators.
- `build_report.py`: deterministic post-processing/export and notebook builder.

Run the notebook from the repository root or its notebook directory. To rebuild
from the local complete raw artifacts, use the command in `build_report.py`.
The notebook execution mechanism and output hashes are in `export_manifest.json`.
