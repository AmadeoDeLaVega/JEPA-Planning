# Planning gradients: distinguish an optimizer bug from a bad physical direction

Status on 2026-11-08: **two synthetic findings verified; real-model derivative
audit not yet run**. This investigation is separate from the frozen
task-protected-metric study and does not change its methods or held-out splits.

## Concrete findings in the unchanged vendored source

Source: `third_party/jepa-wms/evals/simu_env_planning/planning/planning/planner.py`,
SHA-256 `6b673d10b30cd66d07b09daa7b96397f367f49387c443731b6d7d2fd148cc0e3`.

1. **The advertised Adam planner does not perform Adam updates.** Its inherited
   loop creates an Adam optimizer but never calls `optimizer.step()`. It instead
   applies `actions - learning_rate * actions.grad`, then clears gradients.
   On a two-coordinate quadratic, two steps at learning rate 0.1 give
   approximately `[0.3600, 1.9200]` for both upstream SGD and advertised Adam.
   Actual `torch.optim.Adam.step()` gives `[0.1996, 0.1998]`. The manual and
   Torch SGD references agree to float32 roundoff. This matters before any
   optimizer comparison, but does not invalidate existing CEM results.
2. **A logged CEM minimum is not necessarily the returned action's cost.** The
   implementation returns the elite mean, while `losses` records the best
   sampled cost. For cost `(a^2-1)^2`, an elite population `{-1,+1}` has sampled
   minimum zero, but its returned mean zero has cost one. Returning a mean is
   an established CEM convention, not inherently a bug. The counterexample shows
   why actual returned-cost and physical-endpoint checks are necessary.

These were executed on CPU with one thread, no encoder, predictor or simulator.
Three regression tests passed. Exact outputs and provenance are in
`planner_optimizer_audit.json`; the reproducible entry point is
`code/experiments/audit_planner_optimizers.py` and tests are
`code/tests/test_planner_optimizer_audit.py`. No upstream source was edited.
These checks do not establish a PushT improvement and say nothing about another
paper's independently maintained implementation.

## The project-worthy question

**When imagined gradient descent lowers the JEPA cost, does its direction
actually improve the object outcome? If not, which link fails?**

Separate three action-space derivatives at the same start, goal and action:

- `g_model`: autograd of predicted terminal feature distance to the eight-photo
  goal prototype, through the frozen action-conditioned predictor.
- `g_encoded`: central finite differences of the same feature distance, after
  actual simulator execution and image encoding.
- `g_object`: central finite differences of the independent object-only
  position/angular error used in the existing project.

Compare model finite differences with autograd first. Then compare
`g_model` with `g_encoded` to diagnose prediction-derivative error, and
`g_encoded` with `g_object` to diagnose task-metric mismatch. Neither pair alone
identifies the other. Real dynamics have contact switches and rendering has
pixel quantization, so finite differences are scale-dependent measurements,
not certified smooth physical gradients.

### Bounded next diagnostic

Reserve exploratory seeds `20265001`--`20265003`, four tasks per seed, with
named independent start/reference/action/photo streams. Retire them after this
audit. They overlap neither prior quotient tasks nor the current `20264...`
study. Use independently generated reference targets, eight safe goal photos,
one model step/five controls, normalized action dimension ten, and a fixed
interior zero action for the local derivative measurement. Do not choose the
probe point after observing physical outcomes.

Use central differences along all ten action coordinates with normalized
steps `{0.05,0.20,0.50}`. Export all three-scale vectors, cosines where defined,
norms, sign agreement, near-zero/undefined rates, active clipping, contact
changes and one-step physical change under the normalized negative model
gradient. Report flat tasks rather than dropping them. The derivative probe is
not itself an optimizer benchmark. No simulator-derived derivative may be used
to guide a purported visual-only planner at test time.

Start with a single permanently retired correctness/timing task. Set a separate
45-minute, four-thread CPU ceiling for this 12-task exploratory audit, scheduled
only when the current study is not using the model. Keep source, outputs and
model hashes; store small action/state/probe tables and stream feature batches.
Do not open confirmatory seeds or increase the task count after seeing results.

Implementation requirements: `encode` can run without gradients and its
context is detached; `unroll` must run with action gradients enabled. The
existing `predict_action_candidates` helper is decorated with inference mode
and cannot be reused for this purpose. Freeze model parameters, use
`torch.autograd.grad` for actions, and verify the entire normalization and
clipping path. A finite-difference/autograd failure is a correctness blocker,
not evidence that gradients are physically unreliable.

## What could follow, without a blind optimizer sweep

One clean baseline change is to retain and explicitly score the best sampled
CEM incumbent, alongside the returned elite mean. That addresses a return-rule
issue, not a new geometry theorem. A corrected Adam or CEM/gradient hybrid must
use real optimizer steps and account for all forward/backward calls and wall
time; five gradient updates are not equivalent in cost to five sampled plans.
No physical gain should be inferred merely from reduced imagined loss.

A more specific candidate, **only a hypothesis at this stage**, is to seek a
descent direction insensitive to the arbitrary choice of equivalent goal photo.
At an action sequence, let `g_k` be each photo's model-cost gradient, `g_bar`
their mean, and `B` an orthonormal basis of `{g_k-g_bar}`. The direction

    d = -(I - B B^T) g_bar

has the same first-order cost change for every goal photo:

    g_k^T d = -||(I-B B^T) g_bar||^2 <= 0.

This identity is elementary constrained steepest descent. It is not a physical
progress guarantee, a finite-step guarantee, or a new projection principle.
The direction can vanish, and removing disagreement can remove useful contact
strategy. Action-space projection is generally different from projecting latent
features before differentiation because the predictor Jacobian intervenes.
Common-descent/MGDA and gradient-surgery controls are needed before claiming
anything novel about using several goal gradients.

Choose a single follow-on mechanism test after the exploratory diagnosis,
freeze its optimizer/return rule and budget, and evaluate on new reserved data.
Do not tune on the 12 diagnostic tasks, the prior 100 tasks, or the currently
locked metric test. If all methods merely improve imagined loss while physical
error worsens, report model exploitation rather than replacing the objective
until a favorable table appears.

## Prior art that limits the claim

- [DINO-WM, Appendix A.5](https://arxiv.org/html/2411.04983v2): already evaluates
  action-gradient planning and reports better results with CEM in its setting.
  Simply adding gradient descent is not new, and this audit is not a replication
  of that benchmark.
- [Bharadhwaj, Xie and Shkurti, L4DC 2020](https://proceedings.mlr.press/v120/bharadhwaj20a.html):
  interleaves CEM and gradient steps. A hybrid is an established baseline.
- [Pinneri et al., iCEM](https://proceedings.mlr.press/v155/pinneri21a.html):
  improves sampling with temporal correlation and memory. Incumbent/sample
  reuse is not a new idea.
- [Fu and Ning, Control-Geometry Straightening](https://arxiv.org/html/2609.35603v1):
  already relates action/latent geometry and finite-horizon curvature to sampling
  and gradient planners. It trains representations; this proposal initially
  audits a released frozen model. Its theoretical assumptions do not certify
  the current DINO checkpoint's gradients.
- [Wang et al., Decision-Metric Alignment](https://arxiv.org/html/2608.18746v1):
  establishes rollout-error, margin and CEM-stage ranking diagnostics. Our object-
  only derivative decomposition would be a narrower empirical investigation,
  not a first discovery that information and planning geometry differ.
- [Bhamidipaty et al., Imperfect World Models are Exploitable](https://arxiv.org/html/2605.15960v2):
  formalizes model/environment preference reversals. Its results motivate care;
  they do not prove failure for this checkpoint or certify a safe trust radius.
- [Sener and Koltun, multi-objective optimization](https://proceedings.neurips.cc/paper/2018/hash/432aca3a1e345e339f35a30c8f65edce-Abstract.html)
  and [Yu et al., PCGrad](https://papers.neurips.cc/paper/2020/hash/3fe78a8acf5fda99de95303940a2420c-Abstract.html):
  combining/conflict-projecting gradients is established. A goal-equivalence
  application needs matched controls and new evidence, not a renamed algorithm.

The strongest immediate contribution is a verified optimizer audit plus a
reproducible way to locate the planning failure. A useful eventual algorithm
must improve real outcomes on new tasks at a stated compute budget.
