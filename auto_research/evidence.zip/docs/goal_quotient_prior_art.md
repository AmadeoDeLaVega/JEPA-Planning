# Research positioning: goal-conditioned nuisance geometry

Primary sources checked on 2026-11-08. This is a scoped course-project study.
The defensible contribution is a controlled empirical comparison and a
diagnostic of generalization across equivalent photographs. Projection,
invariance, partial goals, and learned planning costs already have substantial
prior art. No claim of a first general solution is warranted.

## Closest work and what it changes

| Work | Relevant existing idea | Difference in this experiment |
|---|---|---|
| [DINO-WM, Zhou et al., arXiv:2411.04983v2](https://arxiv.org/abs/2411.04983v2) | Predicts pretrained spatial DINOv2 patch features and optimizes action sequences toward visual goals. | We keep its released encoder and predictor frozen and change only endpoint scoring. |
| [What Drives Success in Physical Planning with JEPA-WMs?, Terver et al., arXiv:2512.24497v4](https://arxiv.org/abs/2512.24497v4) | Studies representation, prediction, and planner design choices. Supplies the repository's vendored implementation and released baseline weights. | We use its DINO-WM baseline, not its best JEPA-WM architecture, and do not claim to reproduce its published task success rates. |
| [Representation Geometry Matters for Planning with JEPA World Models, Hu et al., arXiv:2608.16287v3](https://arxiv.org/html/2608.16287v3) | SCALE uses task-state supervision during training to align latent distances with physical state differences. Earlier versions have a different title. | No encoder training or pose labels enter our metric fit. Equivalent-photo grouping is still supervision about which visual changes can be ignored. |
| [Latent Projection for Latent Planning, Jang and Ryoo, arXiv:2610.26979v1](https://arxiv.org/html/2610.26979v1) | Fits global constrained dynamics on LeWM latents and retains predictable directions. Its covariance argument depends on Gaussian/Markov assumptions. | We remove variation observed within one task's equivalent goal set. We neither fit dynamics nor assume DINO features follow SIGReg's distribution. The projection idea itself is not new. |
| [Time-to-Goal, Yu and Ye, arXiv:2611.05847v1](https://arxiv.org/html/2611.05847v1) | Learns a temporal ranking metric on frozen LeWM representations. | We fit no temporal head. A trajectory's elapsed time and membership in a task-equivalent image set provide different information. The team's temporal-cost failure is not a refutation of T2G's different setup. |
| [The Planning Limits of Latent World Models, Alrasheed et al., arXiv:2609.39235v1](https://arxiv.org/html/2609.39235v1) | Evaluates action ranking versus goal/rollout horizon, including exact-dynamics diagnostics. | We isolate nuisance-photo variation at a fixed short horizon. Horizon mismatch remains a separate limitation; good finite-bank ranking alone would not establish long-horizon planning. |
| [Goal Sets, Not Goal States, Vélez García et al., arXiv:2606.09476v1](https://arxiv.org/abs/2606.09476v1) | Makes the success-defining variables queryable rather than requiring exact full-state matching in offline goal-conditioned learning. | We infer a limited visual nuisance span from equivalent photos, without state-query masks or changing the offline learner. The partial-goal motivation is established prior art. |
| [Know Thyself: Transferable Visual Control Policies Through Robot-Awareness, Hu et al., ICLR 2022](https://arxiv.org/abs/2107.09047) | Separates robot and world dynamics/costs using robot knowledge. Shows why matching the robot in a goal image can be undesirable. | We use no robot segmentation or analytical robot model. Ignoring agent appearance is already a known control concern. |
| [Efficient Pattern Recognition Using a New Transformation Distance, Simard, LeCun and Denker, NIPS 1992](https://papers.nips.cc/paper_files/paper/1992/hash/26408ffa703a72e8ac0117e74ad46f33-Abstract.html) | Tangent distance constructs locally transformation-invariant distances. | Our affine-span distance is a sampled, feature-space relative of tangent distance. Sampling equivalent goals and applying spatial factorization do not make the underlying projection algebra novel. |

## What the team already established

At base commit `d07cd78`, `docs/pusht_multi_goal.md` reports that goal-prototype
averaging improves PushT finite-bank regret and final physical error. The
temporal-cost branch merged on November 7 reports several negative learned-cost
results, including better overall ordering without better selected actions.
Those are useful findings, not blank space to overwrite or quietly repeat.

The original `proposal/JEPA.pdf` proposes a shared 32×384 patchwise linear
metric trained with equivalent-target positives and different-target negatives,
including a target-versus-hand-configuration allocation study. It explicitly
acknowledges that discarding dimensions can delete useful object information.
Our goal-conditional projection is a training-free geometric control, not an
implementation of that contrastive head. It has no different-target training
negatives. Its failure would not falsify the proposal's task-preserving training
objective or establish that a learned low-rank adapter cannot help.

## The specific question still worth testing

For additive features z=(object, agent), infinitely many averaged goal photos
remove the goal agent's cross term but leave a penalty on the candidate agent's
own feature norm. Distance to an estimated affine nuisance span can remove
that penalty, if the nuisance span is accurate and disjoint from object signal.
With nonlinear patch features, neither assumption is guaranteed.

This motivates four checks together:

1. Improvement against the same-photo-budget prototype, not only one photo.
2. Independent nuisance-photo transfer, not only zero distance on fitted goals.
3. Preserved response to an object change at matched agent positions.
4. Physical selected error and regret, not only global rank correlation.

The spatially factorized extension asks whether a block-diagonal nuisance
covariance makes better use of a small goal set than one global low-rank span.
It trades stronger spatial structure for a much larger removable subspace.
Its success must be judged empirically; more fitted invariance is not itself
evidence that the cost is better for planning.
