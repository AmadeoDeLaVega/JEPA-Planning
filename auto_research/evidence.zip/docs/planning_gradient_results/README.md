# Planning-gradient audit

Status: 24 checkpoint-free tests, the retired real-model correctness/timing
task and the frozen 12-task exploratory audit passed their correctness gates.
Source/protocol/model identities were frozen at 03:15:35 UTC on 2026-11-08.
This is separate from the protected-metric experiment; it does not change or
consume that study's official tasks.

**Result:** object coordinate derivatives are flat on all 12 tasks at all three
steps. Object-gradient cosines are therefore undefined. The ordinary gradient
direction improves one object at step 0.50; the common-descent control improves
none. This near-hold probe does not establish an algorithm gain or diagnose the
metric/object link. See `findings.md` and the executed
`../../code/notebooks/planning_gradient_audit.ipynb` for the complete results.

The retired task took 17.14 seconds, or 21.44 seconds including model loading
and comparison-index construction, with 0.925 GiB peak RSS. Autograd versus
imagined finite differences had cosine 0.99999997 at both fixed epsilons and
relative L2 errors 0.000238 / 0.001317. No state/pose reuse or clipping was
detected. These are engineering checks, not physical-performance findings.
See `engineering_validation.json` for exact evidence and retained limitations.

## Question and fixed exploratory design

Does the frozen model's action derivative point in the same direction as the
real encoded-image cost derivative, and does that derivative agree with object
progress? The audit separates those two links rather than attributing every
planning failure to an optimizer.

- Permanently retired correctness/timing seed: `20265000`, task 0.
- Exploratory audit: `20265001`–`20265003`, four tasks per seed, 12 total.
- Each target is selected by the existing `independent_reference` helper from
  16 separately sampled reference chunks before probe outcomes exist. Eight
  equivalent goal photos use safe reset checks and independent agent proposals.
- Invalid base-goal object/wall geometry or exhausted safe-photo proposals
  reject the entire reference before any features or gradients. At most 100
  attempts use explicit proposal units `task + 1_000_000*attempt`; every rejected
  reason and RNG stream is recorded. No local target perturbations are required.
- The local probe point is a fixed interior **normalized zero** 10D action,
  one model step containing five 2D controls. Its physical controls equal the
  dataset action mean, so normalized zero need not mean no motion.
- Coordinate central differences use exactly 0.05, 0.20 and 0.50 normalized
  units. Each task has 60 coordinate probes, one baseline and six directional
  probes. Report all tasks, including flat physical responses.
- No old quotient-study tasks or current protected-metric seeds are used.
  The 12 exploratory tasks cannot subsequently serve as confirmatory data.
- Before encoding, exact initial/reference states and goal/object poses are
  checked against available old banks and current metric-study metadata hashes.
  Current feature archives need not be loaded. Identical action chunks alone
  are logged with start/goal context and are not treated as task reuse. Historical
  reconstructed task definitions are distinguished from missing old raw bytes.

The three vectors share an action coordinate system and target:

1. `g_model`: action autograd through the frozen predictor's one-step unroll.
2. `g_encoded`: coordinate differences of the same feature cost after actual
   physics, rasterization and frozen DINO encoding.
3. `g_object`: coordinate differences of object-only physical error, combining
   position pixels and wrapped angle with a 50 pixels/radian scale.

The feature objective is mean squared distance to the eight-photo feature
prototype. Cost reduction is float64; predictor and encoder remain float32.
Context features are encoded under `no_grad`, not inference mode. Model weights
are frozen and `torch.autograd.grad` requests only action derivatives.

## Correctness and exploratory control

Before physical interpretation, action autograd must agree with imagined-cost
central differences at one of the two fixed epsilons, 0.001 and 0.01. The gate
requires relative L2 error at most 0.02 and cosine at least 0.999, or both vectors
below the declared flat threshold. Both epsilon results are retained. A failure
blocks interpretation; it is not evidence of a scientific gradient failure.

Two directions are evaluated at the same three physical step lengths:

- The unit negative mean model gradient.
- An exploratory equivalent-goal common-descent control. Center each photo's
  action gradient, form their disagreement span B, and set
  d = −(I − BBᵀ) mean(g). Normalize d only when nonzero.

Every photo has the same first-order derivative along the unnormalized control,
g_kᵀd = −||d||², up to numerical rank tolerance. This is established constrained
or multiobjective steepest descent, related to MGDA and PCGrad. It is **not** a
new projection algorithm, a finite-step descent guarantee or a guarantee of
physical progress. No optimizer settings are tuned here.

## Reproduction

Run from the repository root, with the released PushT checkpoint and project
environment already present. Coordinate the exclusive model slot first. Each
model run is bounded to four CPU threads, 8 GiB peak RSS, 500 MB output and
45 minutes; a caller should also apply an external 45-minute timeout.

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  .venv/bin/python -m pytest -q code/tests/test_probe_planning_gradients.py

OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 \
  timeout --signal=TERM 45m .venv/bin/python \
  code/experiments/probe_planning_gradients.py --phase engineering \
  --output results/planning_gradients/engineering

.venv/bin/python code/experiments/probe_planning_gradients.py --phase freeze \
  --engineering-manifest results/planning_gradients/engineering/manifest.json \
  --output docs/planning_gradient_results/freeze_manifest.json

OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 \
  timeout --signal=TERM 45m .venv/bin/python \
  code/experiments/probe_planning_gradients.py --phase audit \
  --freeze-manifest docs/planning_gradient_results/freeze_manifest.json \
  --output results/planning_gradients/audit
```

The source/protocol freeze requires successful engineering evidence and must
precede opening any audit task. Changed source or model identities invalidate
the freeze. Existing output paths are never overwritten.

The committed freeze records this run's original engineering-evidence path.
On another machine, use fresh output locations for engineering, a new freeze
file and the audit, updating the three command paths consistently. Preserve
the recorded freeze rather than editing its evidence paths. The executed
notebook is independently portable: it uses the small committed JSON/NPZ files
and does not need the original cloud paths, ignored raw outputs or a model.

## Output contract and limitations

Each task saves small compressed arrays of reference/start/goal states, action
controls, per-control physical states and contact counts, all scalar costs,
all three-scale derivative vectors, individual photo gradients, and endpoint
image hashes. Features and RGB images are streamed and discarded. Manifests
include source/checkpoint hashes, pinned DINO revision and encoder weight hash,
named RNG streams, exact command, versions, elapsed time and resource usage.

`summary.json` retains explicit defined/undefined cosine counts, near-zero
derivatives, sign agreement, contacts, clipping, pixel-identical probes and
physical changes at every declared step. Contact counts are the simulator's
per-control contact-count summary, not a trace of every contact pair/substep.
Physics contact switches and image quantization make finite differences
scale-dependent observations rather than certified smooth derivatives.

The audit is local and one-step. It cannot establish closed-loop planner gains,
benchmark replication, or a useful trust radius without further independently
reserved evaluation. Simulator derivatives are diagnostic labels and cannot be
used to guide a purported visual-only planner at test time.

See `../jepa_planning_gradient_investigation.md` for the two separately verified
upstream optimizer/return-rule findings and relevant prior art.
