# Frozen-model gradient audit: correct autograd, mostly flat object response

## What was learned

The action-gradient implementation is numerically correct. In this fixed
near-hold probe, however, a lower imagined image-feature cost almost never
produces object progress. The equivalent-photo common-descent control lowers
imagined cost but is physically ineffectual here. **There is no demonstrated
algorithm improvement.**

These are **12 exploratory tasks from three seed banks**, with three repeated
finite-difference scales. They are not 36 independent tasks. All tasks, flat
responses and zero-displacement references are retained.

## Checks and provenance

- Seeds `20265001`–`20265003`, four tasks each. The separate engineering seed
  `20265000` was permanently retired and excluded from these results.
- Source, protocol, model checkpoint and actual DINO encoder bytes were frozen
  before these 12 outcomes. No optimizer, step, rank or selection rule changed.
- Imagined finite differences agree with action autograd on **all 12 tasks at
  both fixed epsilons**. At 0.001 the minimum cosine is 0.99999873 and maximum
  relative L2 error is 0.0016325. At 0.01 they are 0.99999955 and 0.0055813.
- No normalized-action clipping or prior state/pose reuse was detected. The
  comparison index contained 85,636 unique identities, explicitly including
  119 current protected-metric metadata files. Original missing historical raw
  bytes are not called verified: older synthetic task definitions were
  reconstructed from byte-verified source in the current simulator.
- The model run took 196.30 seconds, used 0.927 GiB peak RSS and wrote about
  1.13 MB. No protected-metric fit, dev or evaluation outcomes were used.

## The probe point matters

The released PushT environment uses relative controls with action scale 100.
Raw dataset action mean is approximately `[-0.0087, 0.0068]`, with standard
deviation `[0.2019, 0.2002]`. Thus normalized zero commands a target offset near
`[-0.87, 0.68]` pixels **per control**, relative to the current agent position.
It is a near-hold command, not a move to the arena center. Commanded PD target
offset is not the same as achieved motion.

A coordinate perturbation of normalized size 0.50 changes only one control's
target by roughly 10 pixels. From safe initial configurations, such probes can
remain below an object-contact threshold. The audit uses one model step/five
controls and a single observed start frame, not the full published closed-loop
benchmark context.

Two reference banks had no object movement among any of their 16 independently
sampled reference chunks: seed `20265002`, tasks 1 and 3. Their target therefore
equals their initial object pose. They were kept as required. The other ten
tasks also have flat object-coordinate derivatives at every fixed scale.

## Derivative decomposition

All 12 model derivatives and all 12 real encoded-image derivative vectors are
nonflat at each scale. Object-error coordinate derivatives are flat for all 12
tasks at every scale. Consequently, **both comparisons involving the object
gradient are undefined on 12/12 tasks**, not zero and not anti-aligned.

| Normalized difference step | Model vs encoded mean cosine | Negative cosines | Pixel-identical coordinate probes | Changed contact-count patterns |
| --- | ---: | ---: | ---: | ---: |
| 0.05 | −0.0569 | 7/12 | 128/240 | 0/240 |
| 0.20 | 0.2919 | 4/12 | 0/240 | 0/240 |
| 0.50 | 0.3344 | 2/12 | 0/240 | 0/240 |

These encoded/object vectors are scale-dependent simulator finite differences,
not certified ground-truth infinitesimal gradients. At 0.05, one coordinate
changes one commanded control target by only about one pixel in the 512-pixel
arena. Rendering at 224 pixels and the PD controller's partial response make
pixel plateaus unsurprising; 128/240 identical rasters strongly confound the
small-scale mean cosine of −0.0569.

The table therefore shows scale-sensitive model-versus-encoded-image agreement,
not universal prediction-derivative failure. It does **not** identify encoded-metric versus
object-error misalignment, because that second link cannot be estimated from
these flat object probes. Real contact/raster finite differences are not
certified smooth physical derivatives. Per-control contact counts also do not
identify every contact pair or substep.

## Fixed-direction physical checks

Negative change in object error means improvement; error combines object
position pixels and wrapped angle at 50 pixels/radian.

| Direction | Unit-direction step | Mean object-error change | Improved / unchanged / worsened |
| --- | ---: | ---: | ---: |
| Negative model gradient | 0.05 | 0 | 0 / 12 / 0 |
| Negative model gradient | 0.20 | 0 | 0 / 12 / 0 |
| Negative model gradient | 0.50 | −0.1676 | 1 / 11 / 0 |
| Exploratory common descent | 0.05 | 0 | 0 / 12 / 0 |
| Exploratory common descent | 0.20 | 0 | 0 / 12 / 0 |
| Exploratory common descent | 0.50 | 0 | 0 / 12 / 0 |

The sole object improvement was −2.0110 pixels-equivalent. The ordinary
direction's **mean** imagined cost decreased at all three steps, but individual
imagined costs decreased on only 11/12, 8/12 and 8/12 tasks respectively. A
finite step is not guaranteed to descend even when its initial derivative is
negative.

The common-descent disagreement span had rank seven on every task. Its raw
direction norm ranged from 0.0000425 to 0.000251, with median 0.000169. Only
0.0606%–0.6095% of the mean-gradient norm remained after projection. Every
photo's raw first-order derivative agreed to within a maximum spread of
`5.97e-18`, as the elementary constrained-descent identity predicts.

Nevertheless, the common control improved **zero** objects at every tested
step. At 0.05 and 0.20 all 12 terminal rasters exactly matched their baseline;
at 0.50, 11/12 did. Its imagined cost decreased on all 12 tasks at every step.
This is an explicit example of imagined progress without useful physical
progress at this probe, not a successful goal-invariance algorithm.

## Useful next research direction

The verified contribution is a reusable failure-localization audit plus the
separate upstream optimizer/return-rule regression checks. These results do
not establish that gradient planning is impossible, that this model has bad
object gradients after contact, or that the common control helps.

A separately frozen, fresh-data diagnostic could stratify pre-contact versus
actual-contact action/state points to make object sensitivity observable.
That would answer a question this near-hold audit cannot. It should not reuse
these 12 tasks as confirmatory evidence, tune a new objective until this table
improves, or feed simulator derivatives into a visual-only test-time planner.
Any subsequent algorithm claim needs matched compute, established baselines
and new closed-loop evaluation. Common-descent/MGDA/PCGrad-style projection is
established prior art, not a new mathematical principle.

## Files and notebook execution

- `audit_summary.json`: descriptive denominators, cosines, norms, signs and
  all fixed-step direction results.
- `audit_task_metadata.json`: all 12 task-level measurements and checks.
- `audit_vectors.npz`: small portable derivative/cost/action/state/contact
  arrays and endpoint raster hashes. No large features or model are needed.
- `data_provenance.json`, `freeze_manifest.json`: source/model/artifact hashes,
  exact run command, resource usage and comparison scope.
- `../../code/notebooks/planning_gradient_audit.ipynb`: six code cells actually
  executed, four captured figures, zero errors. Execution used one in-process
  IPython shell with inline Matplotlib rich-output capture because this
  environment blocks Jupyter kernel sockets. Export and execution took 2.00
  seconds in Python 3.10.19, NumPy 1.26.4 and nbformat 5.10.4. The notebook
  itself is portable and reads the saved artifacts above, without model or
  simulator imports. Its standard Run All works where kernels are available.
  A later cosmetic axis-label repair re-executed all six cells in 1.60 seconds
  and regenerated all four figures. Visual QA and scientific-source/data hash
  checks passed; no scientific values or protocol changed.

See the local README for commands, the frozen design and the numerical tests.
