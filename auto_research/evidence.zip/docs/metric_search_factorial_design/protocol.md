# Exploratory metric × CEM return factorial pilot

This additive, fixed six-task pilot asks whether the original proposal's
contrastive adapter, independently supported on finite candidate banks,
continues to help when CEM adapts its candidate distribution to that metric.
Rank-32 blind directions and world-model exploitation are plausible failure
modes. This pilot does not retrain, tune, replace a previous winner, or make a
confirmatory claim. All prior positive and negative studies remain unchanged.

## Fixed scope and normalization

- Retired engineering: seed 20269000, task 0, excluded from scientific effects.
- Exploratory pilot: seeds 20269011 and 20269012, tasks 0, 1, 2 each. Run all six
  regardless of partial outcomes. No additional split or tasks after effects.
- Four arms, in order: prototype/final mean, prototype/evaluated incumbent,
  learned/final mean, learned/evaluated incumbent.
- Learned matrix is the **first prespecified head**, calibration seed 20264001,
  temperature multiplier 0.1 (absolute training temperature
  0.11518960035985633), rank 32 × 384. Exact NPZ SHA256:
  b742fa0ec17616d9f56920c56bb1d5f1c0b504cad681a70dee30600b174b3aee.
- Prototype: FP64 mean over patches and channels of squared difference from the
  eight-photo prototype. Learned: mean over patches of summed squared projected
  differences, divided by squared Frobenius norm of L. No extra channel or rank
  division. The world-model unroll remains in the original feature space; only
  endpoint costs are projected. No training, head/temperature selection, or
  additional hyperparameters.
- Fix eight safe goal photos before any planning, using the existing independent
  16-reference maximum-displacement rule. Keep zero-displacement targets,
  no-contact cases, failures and ties. Whole-family retries: at most 100, only
  invalid geometry, proposal unit task + 1000000 × attempt. Never accept/reject
  from model cost, physical improvement or contact.

## Continuous execution and exact budgets

Each arm has a separate simulator, reset to the identical initial state once.
Keep its space, contacts, all velocities and dynamics across three replans and
15 total controls. Never reset to a terminal seven-dimensional state. Re-encode
the actual current observation at every replan. Compare all four initial raster,
proprioceptive and full 18-field body states before planning or motion.

Each replan: one model step = five relative 2D controls; two CEM iterations,
64 samples, eight elites, clipping ±2, explicit scoring of both updated means,
stable elite sorting and chronological incumbent ties. Common normals use
PCG64 SeedSequence([bank_seed, task, replan, 690]). Within each metric, both
first-replan streams must match exactly before motion. Different metrics may
produce different adaptive second populations. All **12 streams actually run**:
130 queries/replan, 390/arm, 1560/task, 216 predictor microbatches at batch eight.
There is no computational-sharing claim. All 15 controls execute, even on success.

Actual endpoints are encoded after each chunk for descriptive imagined-versus-
actual feature diagnostics: 12 extra frames/task, no extra planning candidates
or predictor queries. Eight goal frames and 12 observed planning input frames
are separately counted. Store each selected prediction while scoring, so no
post-hoc predictor query is hidden. Save both metrics on selected imagined and
actual features, full/projection/null-space prediction residual energy, and all
four physical outcomes at initial/5/10/15 controls. Different metric scales are
never compared as if interchangeable physical units.
The row-space diagnostic uses an SVD basis with singular-value cutoff
eps_float64 × max(L.shape) × largest singular value, logging rank and cutoff.
This diagnostic basis never changes the fixed learned planning cost.

## Engineering and freeze

Before pilot generation, require completed 100-task adapter and completed
20-task continuous CEM data, including exact metadata, manifests and raw trace
hashes in the prior-identity audit. Same paired-task labels permit shared starts
and goals; exact state/pose reuse across distinct tasks is rejected. Equal
actions at different starts are logged, not censored. Include retired engineering
in the final rebuilt prior receipt.

Post-execution actual-state/pose equality is a separate descriptive audit.
Distinct task trajectories can converge to identical wall poses or states, so
these overlaps never stop/remove a task or enter the same-cohort pre-planning
gate. Save paired-task and initial/goal context for interpretation. All six
denominators are retained; no resampling or outcome-dependent filtering.

Freeze protocol, runner/tests/report code, effective YAML and normalization,
vendored model/simulator tree, actual pinned DINO source tree and weight bytes,
checkpoint, adapter bytes, complete prior receipts, passing fake-environment/
numerical tests and retired engineering evidence. Verify source/input receipts
again before pilot. Engineering verifies every one of 12 return certificates,
full initial body equality, within-metric first streams, continuous dynamics,
projected cost against the original adapter.score API up to the fixed saved
goal-photo variance, and complete physical replay of each 15-control sequence
from its initial state (60 extra engineering controls, never terminal restores).

All engineering plus pilot: ≤1200 active seconds, four CPU threads, 8 GiB RSS,
500 MB new data, stop by 2026-11-08 06:38 UTC. No models/tests/simulation before
the coordinator's explicit exclusive slot. If engineering timing plus a 10%
pilot allowance and 45 seconds reporting cannot fit, stop before pilot. A
resource interruption yields an incomplete fixed pilot, no partial effect claim.

## Planned display and interpretation

Physical error = sqrt(position_pixels² + (50 × wrapped_angle_radians)²).
Primary display is final error after chunk 3. Report every task and all four
error/success means. Leading contrast is prototype/incumbent error minus
learned/incumbent error, positive favoring learned. Factorial interaction is
(prototype/mean − learned/mean) − (prototype/incumbent − learned/incumbent).
Positive interaction means the metric's apparent gain is larger with final mean.
Intermediate errors, diagnostics, contacts and runtimes are descriptive only.
No p-values, confirmatory threshold, winner replacement, or claims that six cases
establish a general algorithm. No bootstrap is planned; two banks are too few
for a reliable uncertainty statement.

Credit the team's original proposal for its contrastive head.
[iCEM Section 3.3 and Appendix E.3](https://proceedings.mlr.press/v155/pinneri21a/pinneri21a.pdf)
already selects the best evaluated sequence and includes the mean candidate.
[DINO-WM](https://arxiv.org/html/2411.04983v2) already studies CEM/MPC and action
gradients, and [Grad+CEM](https://proceedings.mlr.press/v120/bharadhwaj20a.html)
already combines sampling and gradients. This pilot claims no new mathematics,
SOTA or full-benchmark reproduction.

## Reproduction

Use repository .venv Python 3.10.19. The coordinator alone authorizes the CPU slot.
Run run_pusht_metric_search_factorial.py with --phase engineering, then --phase
freeze, then --phase pilot. Finally run report_metric_search_factorial.py to
create the executed notebook, readable figures, report and compact arrays.
