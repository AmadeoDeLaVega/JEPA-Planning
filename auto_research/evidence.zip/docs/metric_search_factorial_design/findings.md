# Metric × search factorial: design and engineering only

The six-case exploratory pilot **was not started**. Its prespecified timing gate
failed before a pilot directory or scientific freeze existed. No six-task mean,
success rate, leading contrast, factorial interaction or inference is available.
The result is an engineered, reviewable design, not evidence that metric and
incumbent gains combine or fail to combine.

The permanently retired engineering task took **153.321s**.
Full preflight plus engineering consumed **178.283s**.
The fixed requirement for the remaining work was **1056.921s**:
six engineering-task times ×1.10, plus45 seconds reporting. The remaining
1,200-second active allowance was **1021.717s**, a
**35.204s shortfall**. The gate was honored, not weakened. The global06:38 stop
and all other resource bounds remained unchanged. All six scientific cases are
unopened, rather than a partial favorable or unfavorable split.

## Verified engineering

- Full repository suite: **412 passed**. Separate focused suite: **60 passed**.
- All four initial18-field body states and input rasters/proprioception matched.
- Both within-metric first-replan populations/costs matched before motion.
- Twelve independent streams actually executed **1,560 planning queries** and
  **216 batch-eight predictor calls**. No shared-computation claim.
- All12 return certificates and cached selected-cost checks passed.
- Original adapter.score versus projected endpoint cost matched up to saved
  goal-photo variance, maximum absolute discrepancy1.11e-16 across12 checks.
- Every complete15-control action sequence replayed from its **initial state**:
  state7/body18 maximum errors0, all16 raster hashes identical per arm. Never
  restore a terminal7D state; all velocities, contacts and spaces remain continuous.
- Engineering executed60 physical controls plus60 separately logged replay
  controls. Encoded8 goal,12 planning-input and12 endpoint-diagnostic frames;
  diagnostics used no extra predictor queries.
- Fixed diagnostic SVD rank32, cutoff7.08957e-14.
  Its row-space basis does not change the frozen learned planning cost.

The sole retired task is permanently excluded from scientific effects. No head,
temperature, task, split, return winner or algorithm was selected from it.

## Prospective design retained unchanged

Four arms cross prototype versus the original proposal's learned metric with
final elite mean versus best explicitly evaluated return. Three continuous
five-control replans per arm;130 queries/replan. Common normals are keyed by
SeedSequence([bank_seed,task,replan,690]), with all12 streams actually running.
Eight safe goal photos are fixed before planning using the existing independent
16-reference maximum-displacement rule. Zero displacement, no contact, ties and
failures are retained. Pre-planning task-definition reuse is a gate; natural
post-execution state/pose convergence is descriptive and cannot filter tasks.

The first prespecified learned head is calibration seed20264001, temperature
multiplier0.1 (absolute training temperature0.11518960035985633),32×384,
SHAb742fa0ec17616d9f56920c56bb1d5f1c0b504cad681a70dee30600b174b3aee. Cost is mean-patch summed squared
projected difference divided by||L||F², with no extra channel/rank division.
Only the endpoint cost is projected; world-model rollout features remain original.
There is no training or retuning.

Pilot cases remain seeds20269011 and20269012, tasks0,1,2. The planned leading
contrast is prototype/incumbent minus learned/incumbent physical error, positive
favoring learned. Interaction is (prototype/mean−learned/mean) minus
(prototype/incumbent−learned/incumbent). These are unestimated, not zero.
The intended six-case report is descriptive only, with every paired task and all
four error/success means, no p-values or unreliable two-bank bootstrap.

The completed100-task adapter and completed20-task continuous CEM receipts were
included in the engineering prior audit. A final post-engineering prior rebuild
and scientific freeze were deliberately not reached because the timing gate failed.
No existing source, release, frozen input or prior positive/negative finding was
changed. The preceding inconclusive20-task transfer result did not alter this
design, cases, metric, scope or timing gate.

The team's original proposal supplies the contrastive head.
[iCEM](https://proceedings.mlr.press/v155/pinneri21a/pinneri21a.pdf) already chooses
the best evaluated sequence and includes means.
[DINO-WM](https://arxiv.org/html/2411.04983v2) and
[Grad+CEM](https://proceedings.mlr.press/v120/bharadhwaj20a.html) precede this local
study. No new mathematics, SOTA or full-benchmark reproduction is claimed.

Portable files contain the full retired trace, exact selected adapter bytes,
source receipt, protocol and passing test outputs. The actually executed
code/notebooks/metric_search_factorial_design.ipynb displays only engineering
continuity/accounting and the failed time gate, never retired efficacy results.
