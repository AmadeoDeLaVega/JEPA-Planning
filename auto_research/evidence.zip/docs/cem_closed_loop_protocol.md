# CEM return-rule scaling: three continuous replans

Additive protocol proposed before any new engineering or confirmation outcomes.
The frozen one-step 100-task study, negative gradient audit and metric/adapter
studies remain unchanged. This extension asks whether the already-supported
local CEM return choice transfers to **three sequential five-control replans**.
It is a bounded scaling check, not a novel optimizer or a reproduction of the
full published DINO-WM benchmark.

## Fixed design

- Retired engineering: seed 20268000, one task, permanently excluded from effects.
- Confirmation: seeds 20268011–20268020, two tasks per bank, 20 tasks total.
- No new development screen and no replacement split after a negative result.
- Targets: independently sampled 16-reference-chunk maximum-displacement target,
  before planning, retaining zero displacement; eight safe equivalent goal photos.
  Whole-reference geometry retries are limited to 100, with proposal units
  task + 1,000,000×attempt. No physical-result/model-cost acceptance filter.
- Same released checkpoint, actual pinned DINO bytes, FP64 prototype cost,
  one observed current frame and one predicted model step/five controls (10D).
- Per replan: two CEM iterations, 64 candidates/eight elites, clip ±2, explicit
  scoring of both updated means, stable elites and chronological incumbent ties.
  Arm A returns the final elite mean; B returns the best explicitly evaluated
  incumbent. Both use the already-tested frozen `cem_return_pair` module.
- Exactly **three replans per arm**, with fixed goal photos and independently
  encoded current observations. Shared normals use
  SeedSequence([bank_seed, task, replan, 680]); observations can diverge.
- Execute **six independent CEM streams per paired task**, 130 queries each:
  390/arm, **780 actually executed**, 108 predictor microbatches at batch eight.
  There is no computational-sharing claim once observations diverge.

## Continuous physical execution is essential

Construct one separate simulator for each arm. Reset each to the same accepted
initial state exactly once, then preserve that environment, space, contact state
and all body velocities for all 15 controls. Never reconstruct an environment
from a terminal 7D state between replans: that state omits block linear/angular
velocity and is not a full simulator snapshot. Store per-control 7D reported
states plus agent/block position, velocity, angle, angular velocity, force and
torque; store observation/endpoint raster hashes and every normalized/physical
action. Encode the actual current observation anew at every replan.

The primary paired outcome is A final object error minus B final object error
after the third chunk, using sqrt(position_pixels² + (50×wrapped_angle)²).
The fixed confirmation requires mean improvement ≥0.5, bank-then-task paired
10,000-resample percentile 95% lower >0, and positive means in ≥8/10 banks.
Bootstrap seed: 20268901. All tasks, zero targets, ties and failures remain.
Intermediate outcomes, success, contact counts, returned imagined costs and
runtime are descriptive. No intermediate-effect-based stopping or continuation.

## Engineering, identity and resource gates

Before the 20 outcomes, freeze source, tests, protocol, checkpoint, actual encoder
bytes, passing numerical tests and retired engineering evidence. Engineering
source scope explicitly includes the selected PushT model YAML, effective
normalization registry, preprocessor and visual transforms. It also hashes every
.py/.yaml/.yml/.json file in the complete vendored model/simulator tree and actual
pinned torch.hub DINO encoder cache tree, in addition to selected local sources.
Missing effective source trees are rejected. Mutation tests reject changed effective inputs
before confirmation. This is prospective coverage hardening, not evidence of
any changed input in an earlier study. Engineering
must verify identical first-step populations/costs from identical observations,
identical full initial agent/block dynamic state (not just frame/proprio),
all six return certificates, deterministic seeded normals, one initial reset per
arm, unchanged simulator-space identity across replans, continuity of full body
state at boundaries, and physical replay of each **complete 15-control sequence
from its initial state**, never via terminal resets. Replay reported/body states
must agree within absolute 1e−5; raster equality is logged separately. Rescoring
the six selected returns adds six explicitly logged engineering-only queries.
Replay adds 30 engineering-only physical controls. No such extras occur on the
scientific confirmation tasks.

Compare exact start/reference/goal identities against available historical raw
banks, prior completed CEM/gradient/metric studies and the completed adapter
confirmation metadata. Include same-cohort task-aware comparisons and log
action-only equality separately. Freeze the adapter completion/hash receipt
only after all its outcomes are complete. No resampling or outcome filtering.
Rebuild the prior index during freeze after the retired engineering trace is
complete, bind its exact index/scope and all raw-bank/metadata/manifest receipts,
and require the same receipt immediately before confirmation task generation.

All engineering plus confirmation gets ≤30 ACTIVE minutes, ≤4 CPU threads,
≤8 GiB RSS, ≤500 MB new storage and the unchanged global 06:38 UTC deadline on
2026-11-08. Model execution requires the coordinator's explicit slot after the
adapter run. If a ceiling is breached, report an incomplete fixed split rather
than interpreting partial effects or choosing extra tasks.

## Prior art and deliverables

[iCEM Section 3.3 and Appendix E.3](https://proceedings.mlr.press/v155/pinneri21a/pinneri21a.pdf)
already chooses the best evaluated sequence and includes a mean candidate.
[DINO-WM Appendix A.5](https://arxiv.org/html/2411.04983v2#A5) already studies
CEM/MPC and action-gradient planning; [Grad+CEM](https://proceedings.mlr.press/v120/bharadhwaj20a.html)
already interleaves sampling and gradients. The present contribution can only
be a careful fresh-task local scaling result with explicit continuous dynamics
and budget accounting, not a new optimizer principle.

Additive paths: `code/experiments/run_pusht_cem_closed_loop.py`, its targeted test,
`docs/cem_closed_loop_results/`, and an executed
`code/notebooks/cem_closed_loop_study.ipynb`. Existing studies remain intact.
