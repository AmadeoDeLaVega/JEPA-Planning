# Fresh confirmation of the original contrastive adapter

## Complete confirmation finding

**The original proposal adapter passed its separately frozen 100-task confirmation.**
For the sole primary comparison, predicted-feature main-eight-photo selection
regret fell from **2.18815 to 1.33379**, a paired mean gain of **0.85436**
pixel-equivalent units, hierarchical 95% interval **[0.17852, 1.76688]**.
Nine of ten bank means were positive, as were all three fixed-head means
(0.66031, 1.02305, 0.87973). Every prespecified support condition passed.

Mean selected physical error was **9.16150 versus 8.30713**. Regret subtracts
the same bank's best available candidate error, so the approximately 39.0%
relative reduction is a **regret reduction**, not a 39% reduction in total
physical error. Success was 95.0% versus 95.67%, a descriptive secondary result.
The primary interval is conditional on these three already fixed calibration
heads; they are not additional independent tasks or an ensemble.

The supported effect is smaller than the selected 24-task development gain of
2.014. Development and confirmation tasks are not pooled. This confirms a
bounded result for the original project method, rather than establishing a new
contrastive-learning concept, long-horizon planning, or broad training variance.
The failed protected-metric primary remains failed and its old 100 locked tasks
remain unopened.

![Primary bank gains](adapter_confirmation_results/primary_bank_gains.png)

## Scientific status

This is a new, separately frozen confirmation of the **original project
proposal's contrastive adapter**, not a replacement primary analysis of the
failed task-protected metric. The protected metric's primary development gain
was exactly zero, and its 100 locked tasks (20264201–20264210) remain unopened.
The prespecified secondary adapter showed development regret 1.332 versus
prototype 3.346, exploratory gain 2.014, interval [0.602, 3.448], positive in
all three development banks. That selected a hypothesis; it did not confirm it.

The new protocol is `docs/adapter_confirmation_protocol.json`, SHA-256
`448fbc487069fabd1971bf8d075b46dbd1ab4a277b354776fbaca8bff24f1b48`.
All 100 predetermined tasks and every method/head/source/photo combination
completed before any effects were inspected. No partial effect was used to
decide whether to finish. The source/model/input freeze was created at
2026-11-08 05:02:45 UTC, before confirmation began at 05:04:14 UTC; the full
cohort completed at 05:30:40 UTC. Its exact freeze SHA-256 is
`759ee36fb530b69ca028cba74bbe763c3e61a75aa607cfcec5b466ff9c0b9d6a`.

## Frozen methods and fair controls

Three already-selected rank-32 adapters, calibration seeds 20264001–20264003,
are loaded without retraining or retuning. Their source registry SHA-256 is
`bda16aac8b5b43b1bd12c24615021f443b2209ab4809f823cdc2c96896ea9220`.
The metric is mean-patch squared projected distance divided by the adapter's
squared Frobenius norm, equivalently a trace-384 channel metric with the same
patch/channel normalization as prototype MSE.

Every task compares prototype, the exact trained adapter, the exact corresponding
random initialization, and an image-label-shuffled adapter. Initialization uses
seeds 20264501–20264503 and preserves the original float32 rounding before
float64 scoring. It is not a newly sampled random projection. Shuffled controls
reassign individual images to groups using seeds 20267601–20267603, preserving
group counts; a mere renaming of groups would not be a valid control.

Shuffled fits use the original 1,024 calibration images per draw, original
initialization/sampling seed, exact absolute selected temperature from that
head's diagnostics (0.11518960035985633, 0.10894150806270747,
0.11628413182073585), 1,000 Adam updates, batch 16, seven distinct negative
groups, learning rate 0.001, no weight decay, and post-update Frobenius norm one.
There is no new validation, temperature search, early stopping or checkpoint
selection. The fit objective receives frozen image features and group identities,
not simulator coordinates or physical-distance labels. Simulator-designed
same/different-target groups are nonetheless privileged structured supervision.

## Independent task population and one primary endpoint

Seed 20267000 is permanently retired for one engineering correctness/timing task.
The ten confirmation banks are 20267011–20267020, ten tasks per bank. Each uses
the unmodified `generate_ranking_task` helper: 16 reference action chunks choose
a physical goal before 64 independent candidate chunks exist, five elementary
controls per chunk, 16 goal photos, and six signed local interventions at four
matched audit-agent poses. A whole-family geometric filter requires valid base
and all intervention targets, with up to 100 deterministic family retries. This
conditioning limits coverage near walls. No task is dropped for low motion,
candidate failure, ties, or disappointing results.

The sole primary comparison is prototype physical selection regret minus
adapter regret using action-predicted features, the main eight goal photos,
and all 64 candidates. Each task's **outcomes** are averaged over three heads;
there is no score ensemble and heads do not add independent tasks. Support
requires all four frozen conditions: mean gain at least 0.5, hierarchical 95%
interval strictly above zero, positive means in at least 8/10 banks, and positive
aggregate means for all three heads. The 10,000-draw bank-then-task bootstrap
uses seed 20267901 and is conditional on these three fixed calibration draws.

Initialization/shuffled contrasts, actual-encoded features, the other eight goal
photos, success, global/best-quarter rank correlations, local sensitivity and
rollout discrepancy are secondary, with exploratory intervals. None replaces
the primary. The scorer exports every candidate cost, physical-error vector,
selected index, exact tie count, cross/residual decomposition, and all pairwise
strict-flip/tie-change masks.

## Controls and transfer results

The table below uses main-eight-photo selections on the complete same 100 tasks.
All values average outcomes over the three fixed heads within each task.

| Method | Predicted regret | Actual encoded regret | Predicted selected error | Predicted success |
|---|---:|---:|---:|---:|
| Prototype | 2.18815 | 1.61460 | 9.16150 | 95.00% |
| Exact original initialization | 2.40996 | 1.43506 | 9.38331 | 94.33% |
| Image-label-shuffled adapter | 6.65608 | 5.74163 | 13.62942 | 83.33% |
| Original trained adapter | 1.33379 | 0.99120 | 8.30713 | 95.67% |

The following regret contrasts and intervals are **secondary and exploratory**,
not substitute primary comparisons or multiplicity-adjusted evidence:

- Trained adapter versus its exact initialization: gain 1.07617,
  interval [0.35532, 1.92575], positive in nine banks.
- Trained adapter versus shuffled-image-label training: gain 5.32229,
  interval [3.42879, 7.68762], positive in all ten banks.
- Exact initialization versus prototype: gain -0.22181,
  interval [-0.62566, 0.13487]. This does not establish equivalence.
- Shuffled training versus prototype: gain -4.46793,
  interval [-6.59740, -2.73697], positive in zero banks.
- Actual-encoded main-photo adapter versus prototype: gain 0.62341,
  interval [0.13913, 1.18904], positive in eight banks.
- Predicted audit-photo adapter versus prototype: gain 1.01301,
  interval [0.31097, 1.93226], positive in all ten banks.

These controls support the value of correct target-equivalence labels for this
fixed adapter and optimization budget. They do not compare every possible
metric-learning method or establish that random-label optimization converged.
All fits used exactly the fixed 1,000 updates. Original and shuffled loss curves,
final-window variation, temperatures, parameter counts and norms are retained in
the executed notebook; low image contrastive loss is not itself a control result.

![Initialization and label controls](adapter_confirmation_results/control_regret.png)

![Original and shuffled learning curves](adapter_confirmation_results/training_curves.png)

The predicted main/audit selection agreement was 88.67% for the trained adapter
and 79.0% for prototype, descriptively. The two photo sets are not identically
distributed repeats: the main eight and first four audit agents are safe for the
base object pose, while the last four audit agents are also safe at all six
signed intervention poses. Agreement therefore includes that safety-conditioning
difference. Photo sets and heads do not increase the number of independent tasks.

![Actual and predicted photo transfer](adapter_confirmation_results/source_photo_comparison.png)

## Geometry and rollout diagnostics

Local target sensitivity increased under the trained trace-normalized metric.
For matched-agent x+, y+ and angle+ interventions, mean squared energies were
1.66376, 1.85818 and 1.35985, versus prototype 0.12758, 0.13908 and 0.16743.
All six signed directions and all four matched agents are exported separately.
This is directional task-signal allocation under a fixed trace, not a uniform
rescaling or proof that nuisance suppression alone caused the selection gain.

The exact candidate-wise rollout discrepancy identity held with maximum absolute
error 2.73e-14. Strict actual/predicted pair-order flips averaged 17.42% for the
trained adapter versus 12.61% for prototype. Thus better physical selections did
not require fewer global score-order flips. Global predicted rank correlations
were 0.55067 and 0.50884, respectively, with best-quarter correlations also
exported. These algebraic and ordering diagnostics do not identify causal
uncertainty or establish a general predictability mechanism. Success, ranks,
local sensitivity and photo agreement are descriptive here; only the stated
secondary regret contrasts receive exploratory intervals.

## Completed cohort and verification

All 100 tasks were retained, including six reference targets with displacement
below 1e-5. The 64-candidate oracle could succeed in 97 of 100 tasks. Reference
displacement quantiles at 0%, 10%, 50%, 90% and 100% were 0.000, 1.760, 32.376,
63.464 and 84.254 pixel-equivalent units. Every task passed on its first whole
family proposal. There were no tied selected minima in the 4,800 actual scored
selections; unit tests additionally retain and validate exact all-candidate ties.

The prior audit indexed 117,040 unique available state/pose/action identities.
There were zero state or object-pose collisions and three action-only overlaps,
which were logged without censoring or resampling. Historical raw-byte limits
remain as stated below. The full pre-confirmation repository suite passed
**376 tests** and the new focused suite passed **36 tests**. The 11 full-suite
warnings were existing SciPy HiGHS and Pyparsing deprecation warnings.

The freeze contains 484 scientific-source entries, including the notebook code
hash, 214 calibration/validation and registry input hashes, nine primary/control
model records, and 712 prior metadata/identity/raw-bank evidence records. The
portable notebook verified 525 original evidence hashes and executed **eight
real code cells with zero errors**. All **four generated figures were visually
inspected** and were readable without clipping. Notebook code still matches its
pre-confirmation freeze; only its actual execution outputs were added.

Control fitting took 142.49 seconds, retired engineering 18.85 seconds, and the
complete confirmation generation/scoring took 1,586.11 seconds. Their combined
active time was **29.12 minutes**, below the 45-minute cap. Peak process RSS was
**1.31 GiB**. The end-of-confirmation guard observed **9.06 GiB** of combined
research result storage before this approximately 32.4 MB portable copy. No paid
compute, old locked-cohort evaluation, source/weight changes, commits or pushes
were performed. Numerical CPU was released after the portable notebook ran;
remaining work was report, hash and visual checking only.

The final artifact inventory includes the two passing test reports and all four
figure PNGs as well as the originally hashed evidence. It is recorded separately
in `adapter_confirmation_results/delivery_integrity.json`, avoiding recursive
self-hashing and preserving the original portable manifest unchanged.

## Integrity, resources and reproduction

A genuinely new dataset schema and seed validator prohibit use of old protected
phases or a fabricated gate. Scientific source (including notebook analysis
code, tests, vendored world-model/simulator and pinned DINO code), model/control,
protocol, calibration/validation cache, checkpoint, encoder-weight, prior-metadata
and engineering/test evidence hashes are frozen before any confirmation task.
The identity audit includes actual stored/reconstructed states/actions and current
metadata across earlier studies. The old phase-level guard only rejected
identity matches between different phases; that is a latent guard gap, not
proof that earlier tasks were actually reused. The new entry point leaves that
helper unchanged and checks the full phase plus task label: repeated goal,
endpoint or diagnostic identities within one task remain valid, while state or
object-pose matches across distinct tasks are rejected even inside one phase.
Focused tests cover both within-task repetition and same-phase cross-task reuse.
Any later audit of earlier cohorts is posthoc integrity checking, not resampling
or a changed estimand. Action-only equality at different starts is logged, not
censored. Historical teammate raw bytes were absent: reconstructed
task definitions are byte-verified against historical sampler/configuration,
but regenerated endpoints are only from the current recorded environment.

The fixed resources are four shared CPU threads, 8 GiB peak RSS, 16 GiB combined
new research storage, 45 active minutes of fitting/generation/scoring, no paid
compute, and the global 2026-11-08 06:38 UTC deadline. Transient raw features are
hashed and discarded after all methods score a task; small heads,
states/actions, metadata, complete cost/decomposition vectors and full hashes
are included in the portable artifact. This avoids unnecessary multi-gigabyte
raw-feature duplication without changing the candidate population.

Use the project `.venv` (Python 3.10.19), from repository root:

```bash
PYTHONPATH=code .venv/bin/python -m pytest -q code/tests/test_adapter_confirmation.py code/tests/test_run_pusht_adapter_confirmation.py
.venv/bin/python code/experiments/run_pusht_adapter_confirmation.py fit-controls
.venv/bin/python code/experiments/run_pusht_adapter_confirmation.py engineering
.venv/bin/python code/experiments/run_pusht_adapter_confirmation.py freeze --tests-report /path/to/passing-pytest-report.txt
.venv/bin/python code/experiments/run_pusht_adapter_confirmation.py confirm
.venv/bin/python code/experiments/run_pusht_adapter_confirmation.py summarize
```

The entry point never overwrites an existing fit, freeze, task phase or portable
bundle. The notebook `code/notebooks/adapter_confirmation_study.ipynb` consumes
only the portable artifact and is executed cell by cell with real IPython rich
outputs, including figures. Its source is part of the pre-confirmation freeze;
execution outputs are not model-selection inputs.

## Attribution and limits

Credit the original proposal (`proposal/JEPA.pdf`, Sections 3–5) for the
same/different-target contrastive head. Learning Mahalanobis/low-rank metrics
from equivalence constraints is established; this study does not propose a new
contrastive-learning concept. The defensible contribution is controlled,
reproducible evidence about the original adapter under independent goals,
proper training controls and frozen model predictions. A positive result does
not establish closed-loop, long-horizon or state-of-the-art planning, and a
negative result does not disprove contrastive learning. This is one checkpoint,
one PushT environment and one five-control model step. For literature context,
see the unchanged `docs/goal_quotient_next_experiment.md` and
`docs/task_protected_metric_study.md`.
