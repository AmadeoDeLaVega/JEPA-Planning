# Adapter confirmation portable artifact

This bundle contains the complete separately frozen 100-task adapter confirmation.
`summary.json` identifies the only primary comparison; other intervals are exploratory.
`selections.csv` has 4,800 rows: 100 tasks x 3 fixed heads x 4 methods x 2 feature
sources x 2 photo sets. Heads and photo sets are repeated measurements, not extra tasks.
`interventions.csv` contains six signed changes at four matched safe audit agents.

Each `tasks/seed_*/task_*/` directory includes `states_actions.npz`, full candidate
cost/cross/residual vectors and strict-flip/tie-change masks in `candidate_costs.npz`,
per-task selections, interventions, and complete generation metadata. The vectors
use keys `h{calibration_seed}_{method}_{main|audit}_{quantity}`. Physical error,
position/angular errors and success are in `states_actions.npz`; selected indices
can be independently recovered by first-index argmin of each stored cost vector.
Object-only error is sqrt(position_error^2 + (50 * wrapped_angle_error)^2).

For physical simulator replay, start from each saved initial state and execute
each full five-control chunk. Convert stored normalized controls using the mean
and std in `confirmation_manifest.json` -> `action_normalization`. Resetting a
saved endpoint alone does not restore its object velocity or reproduce its image.
Goals are reset-verified static photographs and have saved state/agent metadata.
Generation streams and whole-family retries are retained, including all rejected
samples. Raw historical teammate bytes were unavailable; current-environment
reconstructions verify task definitions, not byte identity of old rendered data.

`models/` contains all three unchanged selected original adapters, three exact
float32-rounded initializations, and three shuffled-image-label adapters. No
checkpoint, encoder weights, videos, or raw feature tensors are included. Raw
feature arrays were hashed before discarding them after every method scored the
task. Full raw model/encoder/source/input identities are in `freeze.json`.
The notebook reads only this bundle and regenerates its tables and figures.

`portable_manifest.json` hashes every delivered evidence file before notebook
figure creation. Its own contents and later derived figure PNGs are not recursively
included. The study report and executed notebook are separate reviewable files.
