# Frozen protocol: conditional goal nuisance geometry

Written before inspecting any quotient experiment outcomes. Base repository:
`d07cd78`, 2026-11-07. This is a new course-project experiment, not a claim of
new projection mathematics or a replication of a paper's benchmark.

## Question

Does using equivalent goal photos to estimate nuisance directions improve
candidate selection over averaging the same photos into a goal prototype?
When does fitting invariance on the observed photos fail to generalize?

## Fixed choices

- Frozen released PushT DINO-WM checkpoint, SHA-256
  `8ec9cb05f22812d7f12e3c216b0637f41641055c0653e503e2746edb981b550f`.
- Pinned DINOv2 source `7764ea0f912e53c92e82eb78a2a1631e92725fc8`.
- Use the team's original 64-candidate, five-control simulator bank generation.
  Goal object poses therefore remain bank-dependent, as in that baseline.
- Replace goal photographs with reset-verified equivalents: reject any reset
  with agent/object geometric overlap or object motion greater than 1e-4
  pixels/radians. The upstream simulator advances physics once at reset, but
  contact need not move the object on its first substep. Both checks are needed.
- Sixteen photos/task: first eight supply fitted subsets, last eight provide an
  independent nuisance-photo audit. Target shifts of +25 pixels in x, rendered
  with four matched agent poses, measure task-signal retention only.
- Goal budgets K=1,2,4,8. Use balanced disjoint subsets (8,4,2,1 groups) rather
  than treat every correlated subset as an independent observation.
- Methods: prototype MSE, partial nuisance removal (strength 0.5), full removal
  (strength 1), and an equal-rank coordinate-scrambled basis control at K=8.
  Keep every observed nonzero nuisance direction, capped at K-1. No outcome
  labels enter fitting or hyperparameter selection.
- Nested candidate budgets 8,16,32,64 from a fixed seeded permutation. The
  primary comparison uses the complete 64-candidate bank. Smaller budgets are
  diagnostic because their physical oracle is different.
- Two feature sources: truly encoded simulator endpoints and predicted endpoints.
  The primary source is predicted, with actual-encoded as a causal diagnostic.

## Splits and decisions

- Development seed 20263001, eight tasks. Use it to debug and decide whether
  scaling is informative, not to select alpha/rank on physical outcomes.
- Evaluation seeds 20263011–20263015, initially 20 tasks/bank. Report every
  predetermined method even if it fails. Do not retune after evaluation.
- Primary effect: paired reduction in physical selection regret, full quotient
  versus prototype at K=8, predicted endpoints, N=64. A positive mean, a paired
  hierarchical 95% bootstrap interval above zero and at least 4/5 positive bank
  means are required to call this a supported gain. Otherwise report failure
  or inconclusiveness, not equivalence. Secondary comparisons are exploratory.
- Average goal subsets within each task first. Resample banks, then tasks within
  each sampled bank, using the same indices for both methods. Never count
  methods, goal subsets, budgets or sources as independent replicates.
- Also report selected physical error, success, global/tail Spearman ordering,
  selection agreement across independent photo sets, and nuisance/object-signal
  retention. In-sample invariance is guaranteed algebraically and cannot count
  as an empirical success.

## Scope limits

This protocol tests finite-bank ranking. It does not establish CEM robustness,
closed-loop success, action-independent object targets, performance beyond
PushT, or broad novelty. If the method loses or only improves actual features,
do not spend compute scaling a full closed-loop claim. Preserve negative results
and make an executable notebook plus reproducible code for the team to review.

## Implementation correction before evaluation

The first eight-task development run used the pose-change check alone. A
separate code review demonstrated that it accepts overlapping shapes before
physics has displaced the object. That development run is superseded, not used
as evidence. Before evaluation, an explicit signed circle/polygon distance
check and simulator integration tests were added. The corrected development
run uses the same seed and fixed methods; no method strength/rank was tuned.
Scoring also caches duplicate arithmetic without changing the mathematical
cost. No evaluation seeds were opened before these corrections.

## Development-driven secondary extension, frozen before evaluation

The corrected development run shows that one global seven-dimensional span
removes little independent-photo nuisance variation. Add a separate secondary
cost that fits seven directions independently in each of the 256 fixed DINO
patches (384 channels/patch). This is a block-diagonal metric, not a different
encoder. Fix K=8, full strength=1, all 64 candidates; do not tune a mixing weight
or select patches using physical outcomes. Compare against the identical K=8
prototype using both feature sources and the same audit photos. The +25 px
object-shift diagnostic quantifies the risk of deleting task signal along with
nuisance variation.

The extension's development decisions/results are exploratory. Evaluation on
the five untouched banks is a secondary held-out check, not a replacement for
the original global-quotient primary hypothesis. Save feature caches in the
main run, then apply the frozen `rescore_pusht_patch_quotient.py` once. Preserve
both costs' outcomes even if neither improves selection. No closed-loop scaling
is justified by an improvement on fitted nuisance photos alone.

Interpretation constraint: the patch metric's total removable rank is up to
1,792, versus seven globally. A difference would support the full higher-capacity
blockwise construction; this comparison alone cannot attribute it to locality
independently of rank. Both still use the same eight goal photos.
