# Planner-visited gradients: complete exploratory diagnostic

At the fixed primary coordinate step0.20, nonflat object-error secants occurred
in **1/20 near-hold tasks and 9/20 planner-visited tasks**.
The paired planned-minus-near-hold fraction difference was **+0.400**,
with paired bank/task bootstrap95% interval **[+0.150,+0.650]**.
This estimates object-cost observability, not an optimizer or control improvement.
All twenty cases, including flats/no-contact/ties, were retained. The paired
transition counts are {'hold_flat_planned_nonflat': 8, 'hold_nonflat_planned_flat': 0, 'both_nonflat': 1, 'both_flat': 11}.

## What was actually run

Ten fresh banks20270011..20270020, two tasks each, one released DINO-WM checkpoint,
one five-control horizon, unchanged eight-photo prototype. Each case compares
normalized-zero near-hold with the best explicitly evaluated action from the
same frozen130-query CEM rule. Simulator costs/poses/contacts never select the
planned point. The checkpoint, encoder,490 source files and protocol were frozen
before the first audit task. Freeze SHA256:726afec7de6c370739e396ef29967014d757178c2db9bda4e195f60d83cde478.

At both points, autograd was checked at two small imagined step scales; all40
point-level correctness gates passed. Model, simulator-encoded visual and object
secants then used identical feasible coordinate pairs at0.05,0.20,0.50. Full
central steps were used where possible, otherwise full inward one-sided steps
with actual float32 denominators. No requested probe was clipped or shortened.
One-sided coordinate counts per200 task/coordinate pairs at each scale:
near-hold [0, 0, 0]; planned
[16, 24, 33].

Official20-task totals:6,640 model candidate queries,40 action backwards,
2,620 encoded frames (including goals/context),12,200 probe physical controls.
Retired engineering is excluded from every effect and separately recorded; its
two fixed five-control probes replayed state7/body18/raster/contact exactly.
All raw costs, denominators, actions, states, body states, raster hashes, contact
counts and source/checkpoint receipts are portable. The notebook recomputes
physical labels and secants from these arrays and refuses incomplete cohorts.

## Link-level outcomes

The following are **conditional descriptive mean cosines**, ordered as
(1) scale-matched imagined versus real visual secants,
(2) real visual versus object-cost secants,
(3) autograd versus scale-matched imagined secants. Each actual denominator is
shown; undefined cases are never filled with zero. They do not estimate an
unconditional population alignment or identify a causal mediator.

- near_hold_zero, epsilon0.05: +0.186 (n=19/20); undefined (0/20); +1.000 (n=20/20).
- near_hold_zero, epsilon0.20: +0.725 (n=20/20); +0.809 (n=1/20); +0.906 (n=20/20).
- near_hold_zero, epsilon0.50: +0.615 (n=20/20); -0.630 (n=3/20); +0.606 (n=20/20).
- CEM_evaluated_incumbent, epsilon0.05: +0.231 (n=20/20); +0.240 (n=9/20); +0.998 (n=20/20).
- CEM_evaluated_incumbent, epsilon0.20: +0.501 (n=20/20); +0.262 (n=9/20); +0.750 (n=20/20).
- CEM_evaluated_incumbent, epsilon0.50: +0.526 (n=20/20); +0.534 (n=9/20); +0.543 (n=20/20).

Raw per-task values, negative counts and medians are retained in the CSV/JSON.
A high autograd-to-imagined cosine checks local model calculus only. It cannot
validate the real predictor derivative or the task metric. Comparisons with
real outcomes must retain the finite-step and selected-denominator caveats.

## Interpretation and caveats

The paired point contrast tests the specific observability limitation exposed
by the earlier near-hold gradient audit. It is not a test of a descent update,
contact causality, long-horizon gradients or closed-loop benefit. Cost secants
can be flat even with some pose movement; contact counters are descriptive.
Finite differences through PD control, contact and rasterization are local
scale-dependent secants, not certified smooth derivatives. Scale-matched
imagined-versus-real visual secants help separate model mismatch from merely
using too-large steps, but do not prove a causal failure mechanism.

Every conditional cosine, its nonflat denominator, undefined count and sign is
in summary.json and the120-row CSV. No zero-filled cosine, favorable-scale
selection, small-denominator population claim or significance gate is used.
Threshold sensitivity1e-8,1e-4,1e-2 is reported unchanged. Intervals are
exploratory bank/task estimates conditional on one model/task distribution,
not externally preregistered or familywise-error controlled. Earlier quotient,
protected, adapter, CEM and unopened-factorial evidence is unchanged.

## Prior art and contribution boundary

[DINO-WM, Appendix A.5](https://arxiv.org/html/2411.04983v2) already tests action-gradient
planning and reports stronger CEM results. [Grad+CEM](https://proceedings.mlr.press/v120/bharadhwaj20a.html)
already interleaves sampling and action gradients. [Control-Geometry Straightening,
Section6 and Appendix C.3](https://arxiv.org/html/2609.35603v1) already investigates
action/latent geometry, physical effect identifiability and learned motion
readouts; its local linear-theory assumptions do not certify this checkpoint.
These primary sources were checked2026-11-08. Our narrower contribution is a
paired choice-of-evaluation-point audit and separation of imagined/real-visual/
object-cost secants, with feasible boundaries and explicit flat denominators.
It adds no new projection principle, latent architecture or hybrid algorithm.

This supplements the original gradient_contact_followup_plan.md without editing
it. The prior completed45MB handoff remains byte-identical. No teammate tracked
file, branch, commit or remote was changed. Reuse the recorded CPU environment.
Open code/notebooks/planner_visited_gradient_study.ipynb and Run All; it needs no
model, DINO download or simulator. Model replication requires a fresh explicit
resource plan because the frozen runner's deadline intentionally expires.
