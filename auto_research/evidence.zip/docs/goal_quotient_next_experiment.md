# Next bounded experiment: task-protected nuisance attenuation

Status: **proposed, not executed**. Written on 2026-11-08 after the completed
goal-quotient study. This is a separate next-study plan, not an amendment to its
frozen protocol, evaluation, conclusions or artifacts. No new data, learned
metric, held-out result or closed-loop gain is claimed here.

## Decision and falsifiable question

Test whether **constraining the task distinctions that nuisance suppression may
discard** improves predicted-endpoint selection over the eight-photo prototype.
Use a full-rank, bounded correction to the identity metric, fitted on new
equivalent-goal groups with explicitly local different-target groups. Do not
repeat a projection-strength sweep on the completed 100 tasks.

The intervention is deliberately small: estimate 32 shared channel directions
from within-target variation, then fit only their attenuation coefficients with
linear constraints protecting different-target prototype distances. It isolates
the task/nuisance tradeoff without forcing a 32-dimensional bottleneck. This is
an application of established constrained metric learning, not a new optimizer,
projection theorem or JEPA architecture.

The null includes a useful outcome: no anisotropic correction improves action
selection beyond prototype averaging, even when its training separations are
protected. A reduced nuisance energy, lower numerical cost or successful
training optimization cannot by itself reject that null.

## Why this experiment rather than the alternatives

Existing results remain intact:

- The team's equivalent-photo prototype is the strongest demonstrated control.
- The quotient study's full global metric did not meet its primary gain rule.
  The patch variant retained less independent nuisance energy, but also less
  object-shift signal, and did not improve predicted-endpoint regret reliably.
- The team's temporal head, ordering loss and MSE blend did not establish a
  gain. Same-trajectory elapsed-time labels do not directly compare branches.
- The original proposal already specifies a shared 32 by 384 patch adapter,
  same-target positives, seven different-target negatives, a calibration-budget
  allocation study and compression/shuffled-label controls. Implementing that
  adapter is valuable planned work, not a distinct new idea. Include it as a
  comparator at one budget; do not quietly relabel it as the new contribution.

Three alternatives are plausible but less discriminating as the immediate test:

1. **Prediction-error whitening or predictable-subspace selection.** The old
   prototype's actual/predicted regret gap, 3.214 versus 4.848, motivates a
   diagnostic, not a proof that uncertainty weighting will help. Predictable
   background can be task-irrelevant, and difficult-to-predict object motion can
   be essential. Quotient selection also failed with actual encoded endpoints.
   An empirical residual covariance could be estimated from fresh transitions,
   but would introduce another fitted statistic and training distribution.
   Defer that intervention until the source comparison below identifies a
   predominantly prediction-induced failure. Do not combine both corrections
   in this first test.
2. **Object masking or a pose readout.** These could supply useful supervised
   upper bounds, but add segmentation or coordinate supervision and answer a
   different question. Do not include pose labels in the proposed metric fit.
3. **Longer horizons or subgoals.** These address a distinct planning limitation.
   They do not resolve why a terminal metric loses short-horizon distinctions,
   and would change several variables at once. Reserve them for a separate
   protocol rather than changing horizons after a negative metric result.

The chosen hypothesis is promising because it directly intervenes on the
observed loss of task signal, is cheap to fit from cached features, and has a
clear negative interpretation. It is not chosen because a development sweep
has already made it look good; no such sweep has been run.

## Method, including what the constraints actually guarantee

Let each frozen image feature have 256 fixed spatial patches and 384 channels.
All feature extraction and prediction use the same checkpoint and preprocessing
as the completed study. Keep original features inside every world-model rollout.
The metric changes endpoint scoring only.

For training target group m with K=8 images, let mu_m,p be its mean feature at
patch p. Form the within-target channel covariance by averaging, with equal
target weight, the outer products of all within-group photo differences and
all patches. Use float64 accumulation and its top r nonzero eigenvectors U,
where r=min(32, numerical rank). Patches are observations for this statistic,
not independent experimental replicates. Fix a relative eigenvalue tolerance
of 1e-8; deterministic eigensolver/sign conventions and versions are recorded.

For j in 1..r define:

- r_j: average squared within-target photo difference along U_j, across groups,
  photo pairs and patches.
- b_mn,j: patch-averaged squared difference between mu_m and mu_n along U_j.
- e_mn: patch-averaged full-channel squared difference between mu_m and mu_n.

Fit attenuation a using scipy.optimize.linprog with HiGHS:

    maximize    sum_j r_j a_j
    subject to  sum_j b_mn,j a_j <= 0.10 e_mn, for every training group m<n
                0 <= a_j <= 0.90

Use the fixed metric and cost:

    W = I - U diag(a) U^T
    J_W(x, G) = mean over goal photos k and patches p of
               (x_p - g_k,p)^T W (x_p - g_k,p) / 384.

The same W acts on every patch. It has no patch-specific weights or encoder
updates. Compute it as raw squared distance minus the weighted projected
distance; do not materialize a 98,304 by 98,304 matrix. There are at most 32
fitted coefficients and 12,288 stored basis entries, plus the implicit identity.

Consequences and cautions:

- W has eigenvalues in [0.10,1], so no latent direction is deleted completely.
  This is a distortion bound, not a physical-ranking guarantee.
- Every training target-prototype pair retains at least 90% of its original
  squared distance. All pairs are constrained, including the local pairs below.
  Prototype separation is still not the same as ordering nearby candidates.
- a=0 is always feasible. For a nonempty basis, a_j=0.10 is also feasible,
  since projection energy is no larger than full energy. Thus an infeasible
  solver outcome is a numerical/implementation error, not a scientific result.
  Identity-like behavior or no useful anisotropic benefit is a valid negative
  outcome. Do not relax the 90% constraint after looking at evaluation.
- Uniform coefficients in a rank-32 U are not an isotropic rescaling of all
  384 channels. Include an actual 0.90 I control, whose rankings must equal the
  prototype's exactly. Uniform scaling must never count as learned invariance.
- Check returned bounds and every constraint in float64, with relative
  tolerance 1e-7 and an absolute 1e-10 floor. Log violations and solver status.
  Handle zero covariance with W=I, and log any different-target feature
  collisions. Do not divide by zero or silently drop difficult negative pairs.
- No norm renormalization is applied before checking the protection constraints.
  For geometry plots also report W divided by trace(W)/384, nuisance-to-local-
  target energy ratios and eigenvalues. Raw energy reduction alone is confounded
  by metric scale and cannot count as a benefit.

## Fresh data and locked splits

Retire every previously inspected task from method selection and new evaluation,
including quotient evaluation seeds 20263011--20263015 and development 20263001,
the team's multi-goal/temporal evaluation and development banks, and the
Meta-World proposal pilot. Old artifacts remain descriptive historical evidence.
They are not a reusable test set. Check the complete existing seed/task manifests
before accepting the new manifest, rather than relying only on this short list.

Predeclare these new splits before generating features or physical outcomes:

| Split | Seeds | Size and use |
|---|---|---|
| Calibration | 20264001, 20264002, 20264003 | Three independent draws; each has 32 target families, four target groups/family and eight photos/group: 1,024 images/draw. Fit all methods separately on each draw. |
| Image validation | 20264011 | Eight new families, four groups/family, 16 photos/group: 512 images. Eight photos make prototypes; eight independent photos audit transfer. No fit on this split. |
| Ranking development | 20264101--20264103 | Eight tasks/bank, 64 candidates/task: 24 tasks. Debug, time and apply the predetermined gate below. |
| Locked ranking evaluation | 20264201--20264210 | Ten tasks/bank, 64 candidates/task: 100 new tasks. Open only once after code, model hashes and all decisions are frozen. |

Seed offsets for object poses, reference actions, candidate actions, agent poses,
controls and bootstrap draws must be separate named streams in the saved
manifest. Distinct seed numbers alone are not evidence of disjoint state data.
Hash stored states/actions and check for duplicates across splits and old tasks.
Keep every family, its target groups, all nuisance photos and all diagnostic
perturbations within one split. No `pusht_noise` episode is used to train the new
metric, avoiding the repeated-scene split issue documented by the temporal study.

### Local negatives without a coordinate-regression target

Each calibration/validation family contains a base object pose and three nearby
poses: x shifted by a seeded sign times 12 pixels, y by a seeded sign times
12 pixels, and angle by a seeded sign times 0.10 radians. Choose exactly one
sign per axis per family in advance, not both signs: this is four target poses,
not seven. Each is a distinct target group. Use the same eight accepted agent
positions across a calibration family's four targets; validation uses 16
matched positions, split into eight main and eight audit photos. Accept an
agent pose only when safe for all four targets.

This makes nearby distinctions occur in the actual preservation constraints,
instead of protecting only far-separated random object locations. All group
pairs, not only same-family pairs, enter the LP. There are 8,128 pairs per draw.
No choice of near negatives uses evaluation outcomes or a learned score.

The optimizer receives only frozen features and group identities. Simulator
coordinates are used to construct these interventions, verify grouping/safety,
and evaluate outcomes. **This is structured task supervision, not fully
unsupervised metric learning.** It is more informative than arbitrary photo
grouping and must be disclosed in all comparisons and image-budget counts.
Group identity gives equivalence and inequivalence, not relative physical
distance. It does not guarantee transfer to unseen object poses, diagonals,
rotations or agent configurations.

Use the corrected explicit agent-circle/object-polygon overlap check and the
post-reset object-pose check from `run_pusht_goal_quotient.py`, not the older
unverified renderer. Reject an invalid entire target family before feature
inspection. Record all failed samples. Agent proposals are independent of target
pose before the safety rejection; conditioning on collision-free validity can
still change their distribution. Matching accepted poses within local families
removes that shortcut locally, not universally.

### Goals independent of the evaluated candidate population

For each new task, sample its initial state using the existing start distribution
and require collision-free geometry and an unchanged object pose after reset.
Using a separate random stream, simulate 16 one-model-step reference chunks,
each consisting of five elementary controls. Freeze the endpoint with largest
object displacement under the existing combined metric as the target, with no
additional jitter. This target-generation rule is fixed before any cost runs.

Only then generate 64 new candidate chunks from the original action distribution.
Do not insert the reference actions into that population. Save reference and
candidate action hashes. Do not discard tasks because none of their 64 candidates
succeeds. The target is reachable by a reference rollout, not necessarily by the
sampled candidate bank. Report oracle success availability and the distribution
of reference displacement, including near-stationary targets.

Use the same independent-reference generator for calibration base targets;
local intervention targets may not be reachable in one step and need not be
because they are calibration photographs, not control trials. Freeze all task
states and target goals before predicting/scoring candidates. The changed target
protocol means new scores are not a numerical replication of the old study.

## Comparators, with no new world-model rollouts per cost

All methods score identical cached candidates and the same main eight goal
photos. Repeat using the separate eight audit photos to measure photo transfer.

1. **Prototype, W=I.** Primary comparator. Also record one- and four-photo
   prototype sensitivity as secondary checks using predetermined balanced
   subsets, averaged within each task.
2. **0.90 I.** Exact-ranking implementation/scale control; choices and regret
   must equal the prototype's, subject only to documented deterministic ties.
3. **Task-protected W.** The primary proposed metric with all fixed constants.
4. **Same-basis, equal-training-nuisance-energy attenuation.** Set all coefficients
   to c=(sum r_j a_j)/(sum r_j), or zero if the denominator is zero. This matches
   removed training nuisance energy while omitting the target-based allocation.
   Its uniform attenuation is feasible within coefficient bounds, but need not
   satisfy the target-protection constraints. Also export the cheap same-trace
   version c=mean(a); do not confuse trace with fitted nuisance energy.
5. **Spectrum-matched random-basis control.** Use a seeded orthonormal random
   384 by r basis with exactly the learned a. This tests channel alignment at
   fixed spectrum, not matched task supervision.
6. **Shuffled-group LP.** Shuffle images into equal-sized groups within a
   calibration draw, fit U and a again, and discard the true grouping during
   fitting. A permutation of group names alone changes nothing and is invalid.
7. **Original proposal's adapter.** Shared 32 by 384 L, Frobenius norm one,
   equivalent-target positives and seven different-target negatives. Use the
   same calibration images, spatial patches and frozen rollout. Train at most
   1,000 updates per fit, batch 16 anchors, Adam at 1e-3, no weight decay,
   normalize L after every update, reject a zero norm, and fix random seeds in
   advance. Define W_L=384 L^T L / trace(L^T L), and use the same /384 patch
   cost as every other metric for both training and scoring. For norm-one L
   this equals mean_p ||L delta_p||^2, the proposal's convention, not that
   expression divided by another 384 or 32. This trace convention keeps the
   random-initialization distance scale comparable to raw prototype MSE while
   retaining the rank-32 bottleneck. Compare
   temperatures {0.1,1,10} times the training prototype-distance median; select
   one temperature globally using mean held-out image contrastive loss across
   the three calibration fits, with a fixed small-to-large tie rule. This is
   nine bounded fits, not an architecture/data-allocation sweep. Report loss
   curves and whether training stabilized; a weakly optimized control cannot
   support a general claim against contrastive learning.

Include seeded random rank-32 compression as a cheap adapter diagnostic. All
trainable methods have the same 1,024-image budget per draw and access to the
same task-group labels. Report compute and parameter differences rather than
claiming equal fitting compute. No nonlinear head, additional feature source,
state regressor, new temperature grid or selected post-hoc blend is added.

## Endpoints, physical outcomes and mechanistic diagnostics

Primary endpoint: paired reduction in physical selection regret versus the
eight-photo prototype, **action-predicted features, 64 candidates**. Use the
team's existing object-only metric:

    error = sqrt(position_error^2 + (50 * wrapped_angle_error)^2)
    regret = selected_error - min_candidate_error.

Success is position error below 20 pixels and angular error below 20 degrees.
Also report separate position/angular error, selected combined error, success,
oracle success availability, runtime and deterministic tie counts. A different
physical oracle at a different candidate budget precludes interpreting regret
alone as an across-budget improvement.

For each method, source, photo set and task, export selected indices and all
cost/error vectors. Secondary diagnostics are:

- Actual encoded endpoints versus predicted endpoints, on identical candidates.
- Photo-set selection agreement and physical error variation across photo sets.
- Overall and physically best-quarter rank correlation, plus selected regret.
  Global rank improvement alone did not predict good choices in prior work.
- Independent nuisance energy and local-target energy, their ratio, and
  trace-normalized energy. Use held-out validation families for local negatives.
- At each ranking task's target, render six signed interventions: +/-12 pixels
  in x, +/-12 pixels in y, +/-0.10 radians. Use four matched safe audit-agent
  poses per intervention. These are sensitivity diagnostics, not new optimizer
  labels or independent control tasks. Failure on one axis cannot be hidden by
  averaging it with easier axes.

For delta=x_actual-mu_goal and residual e=x_predicted-x_actual, the per-task
metric score discrepancy is exactly:

    J_predicted - J_actual = mean_p [2 delta_p^T W e_p + e_p^T W e_p] / 384.

The same formula holds for mean squared distance to the photo set because its
candidate-independent goal-variance term cancels. Export both terms and the
candidate pairwise score-order flips. This separates geometric misranking from
rollout-induced score distortion without fitting another model. It does not
identify causal uncertainty or imply that whitening residuals will improve
physical choices.

## Fixed selection, uncertainty and stop rules

The primary estimand averages each task's metric over its three independently
calibrated heads, **not an ensemble of scores or extra task replicates**. Report
each calibration draw separately as well. The main hierarchical bootstrap
resamples the ten test banks, then tasks within the selected banks, preserving
all methods/photo sets/sources/calibration draws together. Use 10,000 draws and
a fixed bootstrap seed. This interval is conditional on these three calibration
draws; three fits do not establish broad training-population uncertainty. Show a
leave-one-calibration-out sensitivity and do not claim training variance is
precisely estimated.

Before opening locked evaluation, require all of:

1. Correct numerical tests, exact isotropic-control rankings and safe rendering.
2. Predicted dev mean regret reduction at least 0.5 pixel-equivalent units,
   positive in at least two of three banks, and positive for each calibration
   draw after averaging its dev tasks.
3. On independent validation photos, a nuisance/local-target energy ratio
   reduction of at least 10% versus identity, with median local-target squared
   distance retention at least 90% and its 10th percentile at least 80%.
   Raw nuisance energy reduction is not the criterion.
4. No nonfinite scores, unresolved split leakage or solver violations.

These are fixed screening rules, not evidence of a held-out gain. If they fail,
publish the development/geometry result and do not open the locked evaluation
just to look for a positive bank. A fix to correctness invalidates affected
development outcomes; document it and require a fresh reserved development
stream, not a scientific retuning of coefficients or thresholds.

On the locked 100-task evaluation, call the primary gain supported only if its
paired mean regret reduction is at least 0.5, the hierarchical 95% interval is
strictly above zero, and at least eight of ten bank means and all three
calibration-draw aggregate means are positive. Otherwise report failure or
inconclusiveness, not equivalence. One primary comparison is confirmatory;
adapter, attenuation controls, geometry and subgroup comparisons are secondary
with explicitly exploratory intervals, not a search for a replacement winner.
This bounded 100-task design has no claimed 80%-power guarantee.

Improvement over the prototype alone would support the full proposed metric.
Attributing it specifically to task-protection constraints also requires a
credible advantage over equal-nuisance-energy attenuation. If the latter works
equally well, the evidence supports restrained attenuation, not the protection
mechanism. An actual-only improvement identifies a transfer failure and does
not justify closed-loop scaling of the metric as deployed.

## Resource ceiling and conditional scaling

Initial study ceiling: **four CPU threads, 8 GiB resident memory, 16 GiB new
generated storage and four wall-clock hours total**. Keep this initial phase
on the existing cloud CPU as a design/resource choice. No paid compute or
teammate branch modifications. Existing authorization for other hardware is
unchanged; this plan neither uses nor revokes it.

- Phase A: calibration/validation generation, fitting and tests, at most two hours.
- Phase B: all three development banks and the gate, at most 45 minutes.
- Phase C: locked evaluation only after passing, at most 75 minutes.

The complete planned data volume is 16,604 encoded frames and 7,936 predicted
candidate endpoints: three 1,024-image draws; 512 validation images; and 124
ranking tasks each with one start, 64 true endpoints, 16 goal photos and 24
additional intervention photos. Independent reference generation adds simulator
steps but no required feature cache. There are at most 57,920 elementary
simulator controls under the 16-reference/five-control design. These counts are
not additional independent evaluation samples.

Time one calibration family, one fitting block and one full development task
before extrapolating. Stream float32 feature caches per target/task, accumulate
covariances and constraint checks in float64, and compute prototype/projected
Gram matrices without allocating all 8,128 full pair-difference tensors. Do not
keep every image/feature copy resident. Record observed peak memory, bytes and
runtime, not just these estimates. A resource stop is a technical/incomplete
outcome, never permission to report a favorable partial test. Evaluation can
resume only with the same frozen code/models and complete predetermined banks;
never decide whether to resume from partial effects.

A primary predicted-feature gain permits writing a **separate** closed-loop
protocol, not an automatic large run. Proposed confirmation: 10 new banks with
four episodes each; prototype, protected metric and original adapter; paired
common CEM random numbers; horizon two model steps, five controls/model step,
64 samples, eight elites, two iterations, four replans. Freeze metrics and
physical targets independently of planners. Preselect calibration seed
20264001 for both learned costs before opening ranking evaluation; never pick
the best-performing evaluation fit or silently ensemble scores. This bounded
closed-loop comparison is conditional on that one calibration draw, unlike the
three-fit-averaged ranking estimand, and must be described that way.
Primary comparison is final object
error versus the same-photo prototype, with success also reported. First time a
complete paired episode and require the full 40-episode comparison to fit a new
explicit four-hour CPU cap. If not, report the resource blocker, check available
already-authorized hardware and freeze a separate resource plan rather than
shrinking the episode count after seeing outcomes. Ask only for material new
costs or permissions. Even a successful short-horizon probe does not
establish robustness to CEM concentration or long-horizon preparatory contact.

## Deliverables and implementation boundaries

If this plan is executed, add separate modules, unit tests, frozen JSON protocol,
state/action/split manifests, model/adapter files, portable per-task tables and
an executed notebook covering positive and negative outcomes. Include tests for
PSD/floors, constraint satisfaction, zero covariance/collisions, scale-invariant
rankings, equal-energy controls, local-family split isolation, no reference-action
insertion, state-safe goal rendering, actual/predicted score decomposition and
bootstrap grouping. Match the repository's documented coding/test standards.

Use the completed study's checkpoint SHA-256
`8ec9cb05f22812d7f12e3c216b0637f41641055c0653e503e2746edb981b550f` and
DINOv2 revision `7764ea0f912e53c92e82eb78a2a1631e92725fc8`. Record current Git
revision/dirty status and hashes of every new source, manifest and frozen model.
Do not edit prior protocols, tables or notebooks to incorporate the new method.
No commit, push or new experiment was performed in preparing this document.

## Sources and limits on novelty

Local primary project sources: `proposal/JEPA.pdf`, Sections 3--5;
`docs/goal_quotient_study.md`; `docs/goal_quotient_protocol.md`;
`docs/pusht_multi_goal.md`; `docs/pusht_temporal_cost.md`; and their experiment
implementations at base revision `d07cd78`. The original proposal is explicitly
credited for equivalent/different-target supervision and its contrastive adapter.

Primary external sources checked on 2026-11-08:

- [Information-Theoretic Metric Learning, Davis et al., ICML 2007](https://bigdata.oden.utexas.edu/publication/information-theoretic-metric-learning/).
  Constrained Mahalanobis metric learning is established. The bounded LP here
  is a deliberately restricted experimental construction, not an ITML replication.
- [Large Scale Metric Learning from Equivalence Constraints, Kostinger et al., CVPR 2012](https://www.tugraz.at/institute/icg/research/team-bischof/learning-recognition-surveillance/downloads/kissme).
  Learning a metric from same/different labels or covariance information is not
  itself novel. We do not implement or claim to outperform KISSME here.
- [LP2, Jang and Ryoo, arXiv:2610.26979v1](https://arxiv.org/html/2610.26979v1).
  LP2 fits constrained global dynamics on LeWM latents and retains predictable
  directions under stated Gaussian/Markov structure. This plan instead uses
  task-equivalence interventions, imposes finite negative-pair protection and
  preserves full rank. No SIGReg/Gaussian premise is assumed for frozen DINO.
- [SCALE, Hu et al., arXiv:2608.16287v3](https://arxiv.org/html/2608.16287v3).
  SCALE aligns latent and privileged task-state distances during LeWM training.
  The present fit has no pose-distance labels or encoder training, but its
  simulator-designed local negative groups remain privileged task supervision.
- [Time-to-Goal, Yu and Ye, arXiv:2611.05847v1](https://arxiv.org/html/2611.05847v1).
  Frozen-model temporal ranking is existing work. Neither this plan nor the
  team's temporal-cost failures replicate or refute that different setup.
- [Decision-Metric Alignment, Wang et al., arXiv:2608.18746v1](https://arxiv.org/html/2608.18746v1).
  Action-ranking geometry, rollout-error/margin diagnostics and CEM-stage
  rankings are established concerns. DA-LeWM jointly trains action-conditioned
  auxiliaries; this plan changes only a frozen-DINO endpoint metric. Their
  full-seven-state PushT diagnostic differs from our object-only outcome.
- [The Planning Limits of Latent World Models, Alrasheed et al., arXiv:2609.39235v1](https://arxiv.org/html/2609.39235v1).
  Goal/rollout-horizon mismatch can survive exact prediction. Our one-step probe
  cannot establish long-horizon planning or resolve that separate limitation.

The defensible possible contribution is a controlled, independently evaluated
test of whether explicit local task protection makes nuisance suppression useful
for this frozen world model. Novelty beyond that requires stronger evidence and
a broader literature comparison; a positive result here is not a state-of-the-art
benchmark claim, and a negative result would not disprove metric learning.
