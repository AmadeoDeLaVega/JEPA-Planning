# Portable task protected metric development results

The proposed protected metric failed its fixed development decision screen. All 24 predetermined tasks and three calibration heads are included. The locked 100 tasks remain unopened. See ../task_protected_metric_study.md and ../../code/notebooks/task_protected_metric_study.ipynb.

- development/ contains immutable scored exports, paired descriptive effects, selected models, full candidate score and physical error vectors, order flips, photograph sensitivities, signed matched interventions, task states and actions, and its original content hashes.
- gate.json and audits/gate_checks.json retain the failed screen and SHA backed correctness evidence.
- validation_geometry*.csv contain protected primary geometry and every control and main versus audit diagnostic.
- adapter_candidates/ and adapter_candidate_manifest.json preserve all nine temperature fits and their complete loss curves. The global selected multiplier is 0.1, chosen only from image validation.
- calibration_validation_states/ contains 104 small family state and reference archives plus original metadata. group_ids match the exact calibration group construction. Large DINO features and raw images are omitted.
- audits/ preserves the predata test, data generation, fitting, historical reconstruction scope, fixed protocol, geometry definition, and predata wall validity amendment.
- rollout_diagnostics.csv, actual_predicted_agreement.csv and figures/ are descriptive notebook outputs. They do not rescue the primary comparison or establish a held out adapter gain.
- bundle_manifest.json hashes every portable file. development/export_manifest.json separately preserves hashes of the frozen analysis export before these supplementary review files were added.

The primary task outcome is averaged across three heads after independent action selection, never by averaging scores or counting heads as tasks. Bootstrap intervals resample banks and tasks with all repeated measurements kept together and are conditional on those heads. All secondary intervals are exploratory development estimates without multiplicity adjustment.

Terminal states verify physical errors, not exact endpoint images. Candidate image reconstruction requires replaying saved actions from initial states because reset advances physics and the saved seven dimensional state omits block velocity. Goal photographs are reset verified static states and are well defined to rerender. Historical regenerated outputs do not certify unavailable old raw bytes.

The notebook uses Python with NumPy, pandas, SciPy, Matplotlib, nbformat, and IPython. From the repository root, the recorded .venv environment can execute it. Its stored outputs were captured by running every real cell in process through IPython because isolated Jupyter kernel sockets are unavailable. No output was simulated.
