# Next diagnostic: gradients at planner-visited actions

Status: a proposed next experiment, **not executed** in this release. Do not
read it as a new result, a permission to reuse previous test tasks, or evidence
that gradients improve control.

## Why this is the useful unresolved question

The completed twelve-task gradient audit used normalized zero actions, which
are near hand-hold controls under PushT's relative controller. All object
coordinate secants were flat at the fixed scales. That makes object-gradient
agreement undefined; it does not locate a failure in the visual metric or prove
that predictor derivatives remain unhelpful once a planned action contacts the
object. The positive CEM return-rule result does not resolve that derivative
question either.

**On the same fresh tasks, is physical sensitivity more observable at an action
chosen by the frozen visual planner than at the near-hold probe, and which link
then limits agreement: predicted-to-actual visual cost, or visual-to-object
cost?** This is a diagnostic about evaluation points, not a new optimizer.

## Bounded design to freeze before running

- Use twenty entirely fresh tasks, ten independent banks of two, with new
  reserved seeds and the existing independent-reference target generator.
  Keep zero-displacement goals, ties, no-contact cases and all failed actions.
  Do not use the current quotient, metric, adapter, gradient or CEM cohorts.
- Freeze the same checkpoint, encoder, eight-photo prototype and CEM settings.
  Each task has two probe points: normalized zero and the frozen model's best
  explicitly evaluated CEM action. CEM uses no physical or contact feedback.
  Do not select a point or retain a task because it happened to contact.
- At each point measure the three links in a common normalized action space:
  predictor autograd, simulator-then-encoder finite differences of the same
  visual cost, and physical-object-error finite differences. Retain exactly the
  same fixed scales and coordinate order at both points where feasible.
- CEM can return clipped coordinates. Before data, specify feasible stencils:
  central differences if both perturbations fit the action box; otherwise a
  signed inward one-sided difference using the baseline. Apply that exact
  stencil to imagined and real costs, save its signed step and denominator,
  and never silently clip a requested difference or call the result central.
  Autograd correctness uses small imagined-only steps separately from larger
  physical secants. Report scale sensitivity rather than one preferred scale.
- Reuse the exact same initial simulator reset for each independent finite-
  difference rollout. Do not reset an intermediate dynamic state, and do not
  feed simulator derivatives, poses or contact labels into the tested planner.
  Contact counts are descriptive and cannot identify every contact pair.
- First report the fraction of nonflat object vectors at each point/scale,
  with paired task/bank uncertainty. Report cosines only on explicitly named
  nonflat denominators; retain undefined values as undefined. A favorable
  cosine among a small selected denominator is not a population alignment
  result. Publish all costs, steps, clipping checks and contact descriptors.
- Before testing a useful descent update, define a separate fresh-data protocol
  with matched model queries, actual optimizer steps and fixed selection rules.
  A derivative audit alone cannot establish a physical algorithm gain.

## Resource and interpretation limits

A retired engineering task should establish actual cost and timing, feasible-
stencil correctness and deterministic replay before selecting a fixed task
count. A reasonable subsequent ceiling is twenty active CPU minutes, four
threads and the existing memory/storage safeguards; if timing does not fit,
reduce the proposed scope **before** opening any official tasks or seek a new
resource plan. No partial-effect-based continuation or replacement split.

Finite differences through contacts, a PD controller and rasterization are
scale-dependent secants, not certified smooth ground-truth derivatives. The
comparison is conditional on this checkpoint, short horizon and synthetic goal
distribution. CEM and gradient hybrids, multiobjective gradient projection and
model-exploitation diagnostics are established prior art; this proposal claims
none of those ideas as new. Its useful contribution would be resolving the
specific observability limitation exposed by the completed near-hold audit.
