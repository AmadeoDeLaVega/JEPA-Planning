# Goal-set geometry for JEPA candidate selection

## Finding

**Estimating a larger nuisance-invariant goal set did not improve held-out
action selection over the same-photo prototype.** On 100 PushT tasks, full
global projection increased mean predicted-endpoint regret from 4.848 to
5.475. The paired improvement was −0.626, with a descriptive hierarchical 95%
interval [−1.551, +0.034]; only one of five seed banks favored projection.
The original gain criterion was not met. The interval crosses zero, so this
does not establish a loss at the 95% level or equivalence.

A spatially factorized extension removed more independent nuisance variation
but also removed substantially more object-change signal. It likewise showed
no supported predicted-endpoint regret gain. The useful contribution is a
controlled negative result, a geometric explanation of what the costs assume,
and a reproducible experiment that tests fitted invariance against actual
physical decisions.

## Why this experiment

The team already has a useful positive result for averaging equivalent goal
photos and several careful negative temporal-cost experiments. Repeating a
generic temporal head would not add much. The next question was whether the
same equivalent photos should estimate directions to ignore rather than only
a less noisy goal mean.

For additive features `(object, agent)`, averaging infinitely many zero-mean
agent configurations removes the goal-agent cross term but leaves a penalty
on the candidate agent's feature norm. A candidate with a correct object pose
and unusual agent appearance can therefore lose to a worse object outcome.
The notebook gives an exact two-dimensional counterexample.

This motivates an affine nuisance control. It does not establish that actual
DINO patch features have an additive or globally linear nuisance structure.

## Methods and the nested-goal-set interpretation

For eight goal features, center the goal matrix and find an orthonormal basis
`Q` of its nonzero span. Score a candidate `x` with

```text
(||x - mean_goal||² - alpha ||(x - mean_goal) Q||²) / feature_count.
```

- **Prototype:** alpha=0; exactly the same candidate ranking as averaging
  squared distance to all supplied goal photos.
- **Half global quotient:** alpha=0.5.
- **Full global quotient:** alpha=1; distance to the goal affine hull, with
  at most seven removed directions.
- **Scrambled-basis control:** permute the basis coordinates, preserving rank
  while disrupting its learned spatial/channel alignment.
- **Patch quotient:** fit independent seven-direction spans in each fixed
  384-channel DINO patch. This development-motivated secondary method can
  remove up to 1,792 directions.

These are nested relaxations: the mean is a singleton goal set, the global
span permits a shared linear combination of goal photos, and the patch metric
permits a different combination in every patch. Consequently, for each
candidate, patch cost ≤ global cost ≤ prototype cost. A smaller numerical cost
is guaranteed and is not evidence of better physical behavior. The patch set
can contain latent combinations that correspond to no valid photograph.

The patch/global comparison changes total removable rank as well as locality.
It cannot isolate the benefit of locality at matched rank. Both use the same
eight photos and store at most `D × 7` basis entries.

No model or cost network is trained. Physical coordinates enter evaluation,
not fitting. However, equivalent-goal grouping is task supervision, and the
simulator supplies these groups. Calling goal acquisition free or claiming
fully unsupervised task relevance would be misleading.

## Protocol and verification

- Base project revision `d07cd78`; existing tracked files were not modified.
- Frozen released DINO-WM PushT checkpoint and pinned official DINOv2 source.
- Five untouched evaluation seed banks, 20 tasks each; one separate eight-task
  development bank. Strength/rank were not tuned on evaluation outcomes.
- 64 shared candidate endpoints per task, each after five simulator controls
  corresponding to one model action. This is a short-horizon ranking probe.
- Both truly encoded simulator endpoints and action-predicted endpoint features.
- Goal budgets 1,2,4,8; balanced goal subsets averaged within each task.
- Two disjoint eight-photo sets per object target. The independent set audits
  nuisance transfer and whether the selected candidate changes.
- A +25 px object-x shift at four matched agent poses measures retained task
  signal. It is one intervention, not a complete test of target sensitivity.
- Explicit agent/object circle-polygon overlap and post-reset pose checks;
  202 photo samples were rejected across the evaluation. A pose check alone
  was insufficient because Pymunk can register contact before displacement.
- Paired hierarchical bootstrap: seed banks, then tasks within banks. Repeated
  goal subsets, methods, sources and budgets are not independent samples.

The main run completed in 1,777 seconds with four CPU threads. It generated
6,400 candidate trajectories, 32,000 elementary simulator controls and 36,800
global-method selection records. Large latent caches remain outside the
proposed commit. Portable exports include 10,400 subset-averaged task rows,
the secondary study, synthetic state banks and 1,000 full-bank decisions.

## Held-out results

All regret values below use the same complete 64-candidate bank. Physical
error is the team's combined position/angular metric in pixel-equivalent units.

| Cost | Goals | Predicted regret ↓ | Actual-encoded regret ↓ | Predicted success |
|---|---:|---:|---:|---:|
| Prototype | 1 | 7.397 | 5.462 | 72.9% |
| Prototype | 8 | 4.848 | 3.214 | 79.0% |
| Half global quotient | 8 | 4.846 | 3.360 | 78.0% |
| Full global quotient | 8 | 5.475 | 3.521 | 76.0% |
| Scrambled-basis control | 8 | 4.848 | 3.214 | 79.0% |
| Patch quotient | 8 | 4.999 | 3.050 | 78.0% |

One-photo values average eight individual-photo choices per task; success is
therefore an expected-photo rate, not 100 independent Bernoulli trials.

Against the eight-photo prototype, predicted-endpoint regret improvements were:

| Alternative | Paired improvement | Descriptive 95% interval | Positive banks |
|---|---:|---:|---:|
| Full global, primary | −0.626 | [−1.551, +0.034] | 1/5 |
| Half global | +0.003 | [−0.342, +0.379] | 2/5 |
| Patch, secondary | −0.151 | [−1.320, +0.750] | 2/5 |

The patch metric's actual-encoded regret improvement was +0.164
[−0.578, +0.958], positive in four banks. That result is inconclusive and did
not transfer to the primary predicted-feature setting.

As a positive control, increasing the prototype from one to eight photos
reduced predicted regret by 2.549 [1.573, 3.647], positive in all five banks.
This agrees with the team's existing qualitative finding on independent banks;
the changed goals and protocol do not reproduce its published numeric table.

## What the geometry diagnostics show

All fitted-goal residuals are approximately zero by construction. On independent
photos and matched object shifts, mean retained energy was:

| Metric, eight fitting photos | Global quotient | Patch quotient |
|---|---:|---:|
| Independent nuisance energy retained ↓ | 71.1% | 42.2% |
| Object-shift signal retained ↑ | 97.4% | 75.4% |

Thus patch factorization bought stronger nuisance suppression while deleting
roughly a quarter of the tested object-change signal. This is consistent with
a task/nuisance tradeoff, but does not prove that signal deletion alone caused
every bad choice.

For predicted endpoints, global full projection reduced global Spearman
ordering from 0.590 to 0.540 and independent-photo selection agreement from
89% to 83%. Patch projection gave 0.527 and 81%. Preserving most object-change
energy or fitting equivalent photos well did not preserve the distinctions
needed to choose the best endpoint.

The notebook also reports physically best-quarter ordering and nested candidate
budgets. When comparing budgets, it uses selected physical error as well as
regret, since the available physical oracle changes with the bank size.

## Scope, prior art and next decision

This is not a new projection theorem, a state-of-the-art planning claim, or a
replication of LP2, SCALE or T2G. Classical tangent distance already studies
invariant distances. The nine-source comparison in
`goal_quotient_prior_art.md` explains the specific differences.

The original project proposal trains a shared 32×384 linear patch metric with
same-target positives and different-target negatives. Our nuisance-only,
goal-conditional control does not implement that objective. Its negative result
does not show that the proposal's contrastive adapter cannot work. In fact,
different-target supervision is a principled way to constrain what invariance
is allowed to discard.

Additional limits:

- Targets are derived from the complete candidate bank, not independently sampled
  long-horizon tasks. Candidate-budget curves are descriptive.
- No CEM or closed-loop improvement was demonstrated. The frozen cost did not
  pass its ranking test, so expensive closed-loop scaling was not justified.
- An agent pose can be irrelevant to the terminal object constraint while still
  mattering for future controllability. This probe grades the immediate object
  endpoint, not long-term contact strategy.
- The study covers one checkpoint, one environment and one object-shift axis.
- Five seed banks give coarse uncertainty. Secondary comparisons are not
  multiplicity-corrected, and crossed-zero intervals do not establish equivalence.

**Project recommendation:** retain the prototype as the strong control. Use this
experiment as evidence that nuisance fitting alone is insufficient, and test
task-preserving contrastive constraints on new training/development groups before
opening a new untouched evaluation split. Do not tune on these 100 tasks.

## Reviewable deliverables

- `code/jepa_planning/goal_quotient.py`: global/patch geometry and paired statistics.
- Three experiment/export entry points, including cached-feature rescoring.
- Four fine-grained test files, including real-simulator collision tests.
- Executed `code/notebooks/goal_quotient_study.ipynb`, portable result/state tables,
  small figures, frozen protocol, literature comparison and reproduction guide.
- CPU dependency snapshot; the team's existing CUDA lockfile is unchanged.

The full repository suite passes 171 tests. Model initialization matched all
predictor/action/proprioception checkpoint keys. The remote workstation hostname
did not resolve, so its workloads were not touched; the cloud CPU completed the
study. No commit, push, branch rewrite, paid compute or external publication was
performed.
