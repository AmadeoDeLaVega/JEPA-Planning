# JEPA Planning: decision-level research handoff

This is an additive research contribution for the existing project, prepared in
an isolated checkout of `d07cd7878cb40ecbd9e1004ef7db6794eb08d1df`. No tracked
teammate file, branch, commit or remote was changed. The public repository HEAD
was checked read-only on 2026-11-08 and was still that base revision. All proposed
additions are reviewable repository-relative files in the companion ZIP.

## What this project can defensibly say

The research question is narrower than inventing a new JEPA architecture:
**when does an apparent improvement in latent geometry or imagined planning
actually change the selected physical action for the better?** The studies
separate equivalent-goal nuisance geometry, task-preserving metric learning,
model derivatives, and the optimizer's returned action. They deliberately use
physical decision error and regret rather than substituting global rank
correlation or attractive latent plots.

This is one released DINO-WM checkpoint in PushT, principally one predicted
model step containing five relative controls. It is not a replication of the
full published closed-loop benchmark, a long-horizon result, a novel projection
principle, or a state-of-the-art claim. Simulator-designed equivalence labels
are structured task supervision even when coordinates never enter the fitting
objective. The original team's proposal already contains the contrastive
rank-32 adapter and deserves that credit.

## Research lineage and reading order

1. **Training-free goal quotient.** Read `goal_quotient_study.md`, then the
   executed `../code/notebooks/goal_quotient_study.ipynb`. On 100 held-out tasks,
   the full global quotient's physical-regret gain versus the same eight-photo
   prototype was -0.626, hierarchical 95% interval [-1.551, +0.034]. It was not
   supported. Independent nuisance suppression alone did not ensure useful
   action selection. The separately credited eight-versus-one-photo positive
   control gained 2.549 [1.573, 3.647]. These results and all 37 original release
   files are preserved byte for byte.
2. **Task-protected nuisance attenuation.** Read
   `task_protected_metric_study.md` and its executed notebook. A full-rank
   constrained metric passed the independent image-geometry screen in all three
   calibration fits, but changed none of the 72 primary predicted decisions
   across 24 development tasks. Its observed physical-regret gain was exactly
   zero. Its fixed gate failed and all 100 reserved tasks remain unopened.
   A degenerate development interval is not proof of population equivalence.
3. **Gradients and optimizer semantics.** Read
   `jepa_planning_gradient_investigation.md`,
   `planning_gradient_results/findings.md`, and the executed
   `../code/notebooks/planning_gradient_audit.ipynb`. Dynamic regression checks
   show the vendored Adam planner never applies its constructed optimizer;
   a separate, tested action-refinement helper supplies real persistent Adam
   and SGD updates without changing upstream files. On the fixed 12-task
   near-hold gradient audit, object coordinate responses were flat at every
   tested scale, making object-gradient cosines undefined. The common-descent
   control did not help. This is a useful observability warning, not evidence
   that gradient planning is impossible or that all model derivatives are bad.
4. **CEM returned-action ablation.** A separately frozen study isolates returning
   the final elite mean versus the best explicitly evaluated action under the
   identical 130-query population. The 12-task development screen passed, so
   its fixed fresh 100-task confirmation passed all criteria: real object-error
   reduction **4.976 [3.241, 6.927]**, positive means in all ten banks, 59
   improved tasks, three worsened and 38 unchanged. Both arms shared the same
   130 explicitly evaluated actions. Read `cem_return_rule_results/findings.md`
   and `../code/notebooks/cem_return_rule_study.ipynb` for the complete analysis.
   The best-seen return rule is explicit iCEM prior art, not a new optimizer.
5. **Original contrastive-adapter confirmation.** The prespecified adapter
   control's exploratory development gain 2.014 motivated a separate fresh
   protocol, not replacement of the failed protected primary. The new 100-task
   confirmation **passed**: predicted physical regret **2.188 → 1.334**, paired
   gain **0.854 [0.179, 1.767]**, nine positive banks and positive means in all
   three fixed calibration heads. Selected physical error was 9.162 → 8.307;
   a 39% regret reduction is not a 39% error reduction. Secondary trained-versus-
   exact-initialization gain was 1.076 [0.355, 1.926], and trained-versus-image-
   label-shuffled gain 5.322 [3.429, 7.688]. Those secondary intervals are
   exploratory and not multiplicity-adjusted. Read
   `adapter_confirmation_study.md` and the executed
   `../code/notebooks/adapter_confirmation_study.ipynb`. Credit the original
   proposal for this rank-32 contrastive head. Its grouping is structured
   supervision, and inference is conditional on the three unchanged fits.
   The failed protected study's reserved tasks remain unopened.

6. **Three-replan continuous transfer.** The separate twenty-task check did
   **not** meet its frozen support criterion. Final error was 11.459 → 9.743,
   paired gain 1.716 with hierarchical 95% interval [-1.870, 5.601], and only
   six of ten positive banks, below the required eight. Ten tasks improved,
   three tied and seven worsened. The observed mean is favorable, but these
   data do not establish closed-loop transfer or equivalence. Read
   `cem_closed_loop_results/findings.md` and the executed
   `../code/notebooks/cem_closed_loop_study.ipynb`. All 120 return certificates
   and physical labels were checked. Each arm preserves its full simulator
   dynamics through all fifteen controls; no terminal-state reset shortcut was
   used. A receipt-path startup correction occurred before any confirmation
   data, preserved both engineering attempts and pre-fix sources, reproduced
   all 31 scientific arrays byte for byte, and counted both attempts in the
   unchanged resource limit. The supported one-step result remains separate.
7. **Metric × adaptive search design, engineering only.** The four-arm
   implementation passed all twelve original-cost equivalence checks and four
   exact fifteen-control physical replays, using the first fixed learned head.
   The prospective twenty-minute resource gate then stopped the experiment
   **before any of the six pilot cases or pilot freeze opened**. Its fixed
   10% timing margin plus 45-second reporting reserve was short by 35.20 seconds.
   No margin was weakened, case dropped, replacement split drawn, or factorial
   effect estimated. Read `metric_search_factorial_design/findings.md` and
   `../code/notebooks/metric_search_factorial_design.ipynb`, an executed
   engineering/design notebook, not a six-task performance result. The ready
   runner and protocol are a bounded next-project contribution. No combined
   adapter-plus-CEM gain is established by the separate studies above.

The ordinary prototype, not a learned adapter, was used in the twenty-task
transfer check. Final verification records **412 passing tests and seven
actually executed notebooks: 41 code cells, zero errors and 25 captured PNG
figures**. The seventh notebook is engineering-only. Two additional GIFs and
two contact sheets in `cem_closed_loop_visualization/` illustrate the posthoc
maximum and minimum gains, explicitly not typical cases or new test evidence.
Their continuous replays match all 64 raw arm-frame hashes and both goal hashes
exactly, with no model calls or altered simulator target. All original 37
first-release files remain byte-identical.

The original quotient, protected-metric, CEM and adapter target protocols differ
in disclosed wall-conditioning and diagnostic requirements. Their absolute
errors must not be combined as one leaderboard or treated as paired outcomes.
All reported intervals retain bank/task pairing. Calibration heads are repeated
outcomes of a task, not additional independent tasks or a score ensemble. Multiple
hypotheses were investigated sequentially; each outcome and fresh split is
reported. No family-wide error control or public preregistration is claimed.
The source/protocol freezes are prospective local evidence, not an external
registration service.

## Review and apply safely

- Unzip into a temporary directory, read the manifest and reports, then copy
  only reviewed additions into a clean current team worktree. Do not extract
  over conflicting files. No commit or push has been made for you.
- `code/jepa_planning/` contains reusable numerical components;
  `code/experiments/` contains bounded, hash-checked runners and summaries;
  `code/tests/` contains checkpoint-free regression tests.
- `docs/*_results/` contains portable tables, compact action/state/cost arrays,
  metric heads, provenance and figures. The executed notebooks analyze these
  without downloading a model or rerunning expensive simulations.
- The ZIP excludes virtual environments, model weights, source checkouts,
  multi-gigabyte latent caches and private working material. Small synthetic
  states/actions and learned metric heads are included for review.
- Use the recorded Python 3.10.19 environment in
  `../requirements/goal_quotient_cpu.freeze.txt`. `.venv/bin/python` was used;
  the obsolete initial `.research-venv` is not part of this handoff. The
  repository's existing dependency/setup instructions still apply.
- From repository root, run `PYTHONPATH=code .venv/bin/python -m pytest -q
  code/tests` with one or two numerical-library threads. Final validation and
  exact file checksums are recorded in `research_handoff_verification.json`.
- Open notebooks in a compatible kernel and Run All, or use the documented
  in-process IPython execution method. Stored outputs were actually computed,
  not fabricated. The analysis notebooks do not need a checkpoint.
- Expensive frozen runners intentionally enforce their recorded deadline and
  refuse overwriting output. A later replication needs an explicit new resource
  plan and output location, not silent edits to the old evidence.

## Reproducibility limits that matter

Seven-dimensional terminal states independently check physical labels but omit
object velocity. Reconstruct endpoint images by replaying the saved full actions
from the initial state, not by resetting a terminal state and assuming its image
is identical. Goal photographs are reset-verified static states.

Historical sampler/configuration bytes were checked and missing task definitions
reconstructed in the current environment. That does not verify unavailable
historical raw endpoint bytes or executed long-horizon planner states. Exact
state/pose identities are checked in addition to distinct seeds; repeated action
chunks at different initial scenes are logged, not censored. A posthoc cross-task
identity audit separately addresses an old guard's same-phase comparison gap
without changing any method, outcome, or task population.

The literature comparison is in `goal_quotient_prior_art.md`, the protected
follow-on plan, and the gradient investigation. Closest prior work includes
DINO-WM, representation/metric alignment, latent projection, time-to-goal,
partial-goal and robot-awareness methods, tangent distance, constrained metric
learning, multiobjective gradient methods, GradCEM, and iCEM. The contribution
here is the controlled evidence and reusable checks, with honest negative
results, rather than claiming those existing ideas as new.

The proposed next gradient diagnostic, `gradient_contact_followup_plan.md`, is
explicitly unexecuted. It asks whether gradients become observable at planner-
visited actions rather than near-hold controls. It is not another result.
