# Reproducing the goal-quotient study

## Two levels of reproduction

1. **Recompute findings and figures without a model.** Open
   `code/notebooks/goal_quotient_study.ipynb` and run all cells. It reads the small
   committed tables in `docs/goal_quotient_results/`, recomputes the primary paired
   interval, and recreates the figures. It needs NumPy, SciPy, pandas and
   Matplotlib, not PushT or CUDA. The tested environment uses Python 3.10.19.
2. **Regenerate observations, predictions and selections.** Follow the model
   commands below. Large feature caches and checkpoints remain ignored, not
   part of the proposed commit.

## Environment

The actual runs used a separate fresh checkout at base `d07cd78`, Python
3.10.19, PyTorch 2.7.0+cpu, torchvision 0.22.0+cpu, NumPy 1.26.4, SciPy
1.15.3, four Torch/OpenBLAS threads and batch size eight. This is a CPU
compatibility environment, not the repository's hash-locked CUDA environment.
It preserves the model architecture and published checkpoint but differs in
some utility-package versions. Comparisons are paired inside this environment;
we do not equate its results with a replication of the original paper.

`requirements/goal_quotient_cpu.freeze.txt` records the exact installed package
versions. It is a version snapshot, not a wheel-hash lockfile, and is intended
for Linux x86-64. Do not overwrite an existing team's `.venv` to install it.
In a **fresh separate checkout** with `uv` available:

```bash
export UV_PYTHON_INSTALL_DIR="$PWD/.tools/python"
export UV_CACHE_DIR="$PWD/.tools/uv-cache"
uv python install 3.10.19 --managed-python
uv venv .venv --python 3.10.19 --managed-python --seed
uv pip install --python .venv/bin/python --index-strategy unsafe-best-match \
  -r requirements/goal_quotient_cpu.freeze.txt
.venv/bin/python code/scripts/download_checkpoint.py --env pusht
```

The existing project CUDA environment can also run the new pipeline with
`--device cuda`; results on that platform need their own provenance and should
not silently replace the recorded CPU results.

## Verified inputs

- Vendored upstream JEPA-WMs source is unchanged, upstream
  `13cf1d9c7e476f53c17714d2e0f1dc239a883ce0`.
- Released PushT checkpoint is 274,877,419 bytes with SHA-256
  `8ec9cb05f22812d7f12e3c216b0637f41641055c0653e503e2746edb981b550f`.
- DINOv2 source is pinned to
  `7764ea0f912e53c92e82eb78a2a1631e92725fc8` during model initialization.
  The temporary loader override is restored on success or error; no vendored
  source is patched.
- Downloaded `dinov2_vits14_pretrain.pth` SHA-256 was
  `b938bf1bc15cd2ec0feacfe3a1bb553fe8ea9ca46a7e1d8d00217f29aef60cd9`.
- Predictor, action encoder and proprioception encoder reported all checkpoint
  keys matched. Optional visualization decoder heads are not loaded.
- No offline trajectory dataset, learned cost, privileged pose training labels
  or external API model inference is used.

## Run the tests and development check

```bash
OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
  .venv/bin/python -m pytest code/tests -q

OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
  .venv/bin/python code/experiments/run_pusht_goal_quotient.py \
  --device cpu --threads 4 --batch-size 8 --seeds 20263001 --tasks 8 \
  --save-features --output results/goal_quotient/dev_new

OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
  .venv/bin/python code/experiments/rescore_pusht_patch_quotient.py \
  --input results/goal_quotient/dev_new --output results/goal_quotient/dev_patch_new
```

The development seed is not an evaluation seed. An early pose-only collision
check was superseded after code review; do not use its outputs as scientific
evidence. Corrected goals require both no geometric agent/object overlap and
unchanged post-reset object pose. Integration tests exercise the real simulator
case where one physics substep registers contact before moving the object.

## Held-out evaluation

The following was run once with all predetermined global methods, then the
frozen secondary patch method was scored on the saved features. Choose fresh
output directories; scripts refuse to overwrite prior runs.

```bash
OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
  .venv/bin/python code/experiments/run_pusht_goal_quotient.py \
  --device cpu --threads 4 --batch-size 8 \
  --seeds 20263011 20263012 20263013 20263014 20263015 --tasks 20 \
  --save-features --output results/goal_quotient/evaluation

OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 \
  .venv/bin/python code/experiments/rescore_pusht_patch_quotient.py \
  --input results/goal_quotient/evaluation --output results/goal_quotient/evaluation_patch

.venv/bin/python code/experiments/summarize_pusht_goal_quotient.py \
  --input results/goal_quotient/evaluation \
  --patch-input results/goal_quotient/evaluation_patch \
  --output docs/goal_quotient_results
```

The summarizer requires a completed manifest, the full expected bank/task/
method/source/budget/subset grid and matching per-bank metadata. The secondary
rescorer's prototype must reproduce the main experiment's prototype metrics
within 1e-10. It reuses the exact seeded candidate permutation even at full
budget, preserving cost tie-breaking and the physically best-quarter membership.

## Outputs and resource scope

Each seed directory contains all selections, geometry diagnostics, simulator
states/actions, metadata and optional per-task float32 feature caches. The
portable export averages goal subsets within tasks and retains every task,
source, candidate budget, goal budget and method. Manifests retain source
hashes, checkpoint identity, command, software versions and runtime. Notebook
outputs and small figures can be committed; checkpoint/feature tensors cannot.
The export also includes small compressed synthetic simulator-state banks and
full-bank selected indices, allowing the notebook to independently recompute
the physical error, regret and success labels for every final decision.

CPU runs are explicitly limited to four threads. The remote workstation could
not be reached through the available SSH alias because its hostname did not
resolve, so no remote jobs, environments, data or teammate branches were touched.
No paid compute or external publication was used. The separate cloud checkout
contains the optional cached features for further review.

The notebook regenerates figure files under `docs/figures/goal_quotient/`.
Keep its working directory inside the checkout so root detection succeeds.
All eight code cells in the delivered notebook were executed, with real text
and image outputs captured and no execution errors. This isolated cloud
environment blocked Jupyter kernel socket startup. Validation therefore used
cell-by-cell in-process IPython with the inline Matplotlib backend, rather than
claiming that a standard `nbclient` kernel run succeeded. The execution method
is also recorded in notebook metadata. On an ordinary workstation, use Jupyter
with the documented environment's `ipykernel` and Run All.
