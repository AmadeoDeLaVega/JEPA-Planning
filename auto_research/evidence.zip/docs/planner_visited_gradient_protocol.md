# Planner-visited gradient observability: prospective diagnostic

A bounded continuation authorized after the earlier release was complete. This
is a new study with its own resource plan, not a reopening of the six-case
factorial or any previous reserved split. Model work stops by 09:30 UTC on
2026-11-08; all work winds down before 10:00 UTC (05:00 America/New_York).

## Question and estimand

The previous near-hold audit found flat object responses. On the same twenty
fresh tasks, does a frozen visual planner's chosen action make object sensitivity
observable, and does disagreement arise in predictor-to-real-image or
real-image-to-object cost? This is an exploratory mechanistic diagnostic. It
neither tests an improved optimizer nor claims smooth derivatives through contacts.

Ten banks, seeds 20270011 through 20270020, exactly two tasks each. Retired
engineering seed 20270000/task0 never contributes to effects. No development
selection and no effect-based continuation. Keep all zero-displacement goals,
no-contact cases, ties and failures. Sample valid tasks using the existing safe
base target/eight-photo generator and independent maximum-displacement 16-chunk
reference; reject only impossible geometry/photos before encoding/planning.
Compare actual state/pose identities with all available previous cohorts before
features. Log repeated action chunks at different starts without censoring them.

The paired evaluation points are normalized zero (near hand-hold, not move-to-
center) and the best explicitly evaluated action of frozen CEM: two iterations,
64 samples, eight elites, action box [-2,2], two explicitly evaluated updated
means, 130 model queries. Prototype is the same eight-photo FP64 patch-MSE cost.
Normals are PCG64 SeedSequence([bank_seed,task,700]). No real cost, pose or contact
label selects the planned action. One model step, five physical controls.

Primary estimand: planned minus near-hold proportion of tasks with nonflat
object-error coordinate secants at epsilon0.20. Nonflat means L2 norm>1e-10,
matching the old audit; additionally report the unchanged complete grid at
1e-8,1e-4,1e-2 thresholds. Secondary descriptive scales0.05 and0.50. Use10,000
paired bank-then-task bootstrap draws, seed20270901, for the primary proportion
and point difference; these are exploratory conditional estimates, no familywise
error control. The same paired resample indices retain points/scales together.
No significance gate changes scope, and no partial-cohort effect is reported.

At each point compute action autograd of the prototype. Small imagined secants
at0.001 and0.01 check implementation: require one scale cosine>=.999 and
relative L2 error<=.02, or both flat. Near a box face central differences would
be infeasible. Use central +/-epsilon where both feasible, otherwise full inward
one-sided difference with baseline. Save both actual float32 action endpoints,
actual coordinate denominator and mode. No clipping/truncation, no pretending
one-sided secants are central. Same stencils measure model, simulator-encoded
visual and physical object costs at scales0.05,0.20,0.50. Report both autograd
vs real secants and scale-matched model secants vs real secants, distinguishing
nonlinearity from predictor mismatch. Cosines are undefined on flat denominators;
report every denominator and counts, not just favorable nonflat means.

Every physical probe starts from the identical full initial reset and executes
its complete five-control chunk. Never reset an intermediate terminal state.
Retain states7, contacts, raw raster hashes and all actual costs/actions. The
object cost is sqrt(position_px^2+(50*wrapped_angle_rad)^2). Contact counts are
only descriptive, not a perfect contact-pair classifier. Exact replay of two
fixed engineering chunks checks dynamics/raster identity. All goals and probes
are deterministic in the frozen environment; model weights remain frozen.

## Limits and provenance

One sequential CPU process, four numerical threads,8GiB RSS,500MB new output,
maximum1,800 cumulative active seconds across engineering/audit. Before freezing,
require complete passing tests/retired engineering and project remaining work as
20*engineering_task_seconds*1.20+60 seconds reporting. If projection exceeds the
remaining allowance or09:30 model deadline, stop without opening official tasks.
Never lower this margin, replace cases or retry partially observed effects.
Freeze source/protocol/checkpoint/encoder bytes and prior identity receipts after
engineering and before any audit task. If source correctness needs amendment,
preserve the failed engineering and rerun it before any freeze.

The claim is observability and localization conditional on one released DINO-WM
checkpoint and a synthetic short-horizon target distribution. Finite differences
involve PD control, nonsmooth contact and rasterization. This does not establish
causal contact effects, global controllability, closed-loop benefit, a new gradient
algorithm, a new latent metric or state of the art. It directly follows the
previously documented gradient_contact_followup_plan.md without changing it.
