# CEM return-rule ablation: frozen plan before real-model outcomes

Protocol proposed on 2026-11-08, before any real-model engineering task. This
study preserves the previous gradient audit and protected-metric study. It does
not tune gradients on those tasks. Its question is deliberately narrow:

**With an identical evaluated CEM population, does returning its explicitly
evaluated incumbent instead of its last elite mean improve real object error?**

## Fixed planner and outcome

Use the same released, byte-verified PushT DINO-WM checkpoint and pinned actual
DINO encoder weights as the previous studies. The cost is FP64-reduced squared
patch-feature distance to the mean of eight safe equivalent-goal photographs.
One observed frame, one predicted model step, five relative controls (10D),
normalized clipping at ±2. This is a one-step decision experiment, not the full
published closed-loop benchmark.

CEM has two iterations, 64 candidates and eight elites per iteration. Initial
mean/std are zero/one; candidate zero is the current mean. Both arms share all
seeded normals, clipping, stable ascending-cost elite selection, elite means and
population-standard-deviation updates. The incumbent NEVER changes a population
update. Explicitly score every updated elite mean, including the intermediate
mean, adding two queries to the 128 population queries.

- A returns the final elite mean and its actual explicitly measured cost.
- B returns the lowest-cost action among all 130 evaluated actions, including
  both updated means. Ties retain the earliest evaluated action.

One shared stream computes the two counterfactual returns. Each arm has the
same 130-candidate query budget; the implementation shares these computations,
rather than falsely reporting 260 executed evaluations. Batch-call counts,
candidate-query counts, wall time, arrays and hashes are recorded separately.
Population sampled minima and actual returned costs are distinct fields. The
incumbent cost certificate is an imagined-cost fact, not a physical guarantee.

The primary paired outcome is A's object error minus B's object error, after
restoring the same accepted initial state and executing the returned five
controls. Object error is sqrt(position_pixels² + (50*wrapped_angle_radians)²).
All tasks and ties remain in the denominator. Success, position/angle error,
contact counts, initial error, imagined and real encoded costs are descriptive.

## Fresh tasks and split

Before CEM or feature scoring, generate an independent safe initial state and
16 reference chunks using the existing named independent streams. The endpoint
with largest object displacement defines the target, retaining zero-displacement
targets. Only the base object's valid geometry and 16 safe goal photographs are
required; no local object interventions are introduced. The first eight photos
form the planning prototype. The other eight are a fixed secondary photo
transfer/rescoring audit, never used to select a return, reject a task or tune.
There is no second photo-audit CEM run or additional planning head.

For invalid geometry alone, retry the entire reference at most 100 times with
proposal_unit = unit + 1,000,000*attempt, starting at attempt zero. Record accepted
and rejected proposal states/actions and all streams. No candidate, model-cost,
success, displacement-threshold or physical-outcome filters are permitted.
Compare actual start/reference/goal states and object poses to all available old
banks and current protected-metric metadata before encoding; log action-only
matches with task context. Missing original historical raw bytes are disclosed,
not declared verified. Do not use any previous study's physical outcomes.

- Permanently retired engineering seed: 20266000, one task.
- Development: 20266001–20266003, four tasks per bank, 12 total.
- Locked confirmation: 20266011–20266020, ten tasks per bank, 100 total.
- Paired hierarchical bootstrap: seed 20266901, 10,000 resamples, sample banks
  then tasks within sampled banks; percentile two-sided 95% interval.

Before development, freeze protocol, source, checkpoint, encoder bytes and
engineering correctness artifacts. Development opens the locked split only if
all correctness/source/budget/leakage checks pass, mean primary improvement is
at least 0.5 pixels-equivalent, and bank means are strictly positive in at least
two of three banks. Failure leaves all 100 locked tasks unopened, with no retune.
Confirmation requires mean improvement at least 0.5, paired hierarchical 95%
lower bound strictly positive, and positive means in at least eight of ten banks.
Only B versus A is primary. No optional gradient arm is included.

## API and correctness gate

`cem_return_pair(cost_fn, normals, *, elites=8, action_clip=2.0)` accepts normals
of shape [iterations,samples,...action_shape], calls a pure batched function with
[candidates,...action_shape], and requires one finite scalar per candidate.
It returns detached NumPy arrays for last_mean_actions and incumbent_actions,
their scored costs/indices, all evaluated actions/costs and kind/iteration
indices, iteration populations/elites/means/stds, query/call counts and runtime.
No model or simulator is imported by the reusable optimizer module.

Before any development outcome, synthetic tests verify nonlinear mean failure,
literal population equivalence to the existing rule, means scored without
changing updates, chronological ties, clipping, finite-input/cost rejection,
130-query accounting and exact action/cost certificates. The retired real-model
engineering task additionally verifies deterministic rerun, stored returned
costs against the same explicitly evaluated actions and matching model/source
hashes. An engineering failure is a blocker, not evidence for the hypothesis.

Model runs require an explicitly assigned exclusive slot. All runs together
have a 45-minute model-run ceiling, four CPU threads, 8 GiB RSS and ≤500 MB new
storage, within the shared global deadline 2026-11-08 06:38 UTC. No real-model
job runs while protected-metric work owns the slot. Features stream through
memory; do not retain 130 predicted feature tensors per task. Encode only the
two returned physical endpoints for real-feature diagnostics. Save small
actions/states/scalars and hashes plus a reproducible executed notebook.

## Reproduce in the existing project environment

Use `.venv/bin/python` (Python 3.10.19), not the superseded research environment.
From the repository root, after obtaining the shared model slot:

```sh
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
  .venv/bin/python -m pytest -q code/tests/test_planning_optimizers.py \
  code/tests/test_run_pusht_optimizer_probe.py

OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 NUMEXPR_NUM_THREADS=4 \
  timeout --signal=TERM 45m .venv/bin/python \
  code/experiments/run_pusht_optimizer_probe.py --phase engineering
.venv/bin/python code/experiments/run_pusht_optimizer_probe.py --phase freeze
OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 NUMEXPR_NUM_THREADS=4 \
  timeout --signal=TERM 45m .venv/bin/python \
  code/experiments/run_pusht_optimizer_probe.py --phase development
```

Only if the complete saved development gate passes, invoke the same command
with `--phase locked`. The runner independently recomputes the gate before
creating any locked output or loading a model. It enforces the cumulative
45-minute model-run limit across phases and refuses overwritten phase outputs.
Retired engineering alone repeats CEM and rechecks the two returned costs:
these 132 extra engineering queries are separately logged and excluded from
the scientific paired 130-query budget. No such replay occurs on study tasks.

## Prior art and limits

[iCEM (Pinneri et al., 2021), Section 3.3 and Appendix E.3](https://proceedings.mlr.press/v155/pinneri21a/pinneri21a.pdf)
explicitly executes the best evaluated action sequence instead of the mean,
and adds the mean as a final-iteration candidate so it can still be selected.
It also uses memory and sample reuse. Thus this exact return-rule principle,
not just generic CEM memory, is prior art. Scoring both updated means outside
the population here isolates the local return choice without changing search.
It is not a new optimizer claim.
[Bharadhwaj et al. (2020)](https://proceedings.mlr.press/v120/bharadhwaj20a.html)
already combine CEM and gradients, and
[DINO-WM Appendix A.5](https://arxiv.org/html/2411.04983v2) already compares
action-gradient planning with CEM. This experiment isolates a local return-rule
choice in this project's reduced-budget wrapper, without claiming to reproduce
or improve those full benchmark systems. A negative physical result is useful:
lower scored imagined cost does not by itself certify a better physical return.
