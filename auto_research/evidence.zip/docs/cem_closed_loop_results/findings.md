# Continuous three-replan CEM transfer check

The complete 20-task/ten-bank transfer check **does not pass** its frozen support rule.
Final object error: A **11.4590**, B **9.7432**.
Paired improvement **1.7159**, hierarchical 95% interval
**[-1.8702, 5.6008]**; positive banks **6/10**.
Improved/tied within 1e−6/worsened tasks: **10/3/7**.

The fixed rule required mean ≥0.5, lower 95% >0 and ≥8 positive banks. All tasks,
zero-displacement references and ties are retained. There was no development
screen, replacement split, physical-result filter or partial-effect stopping.
This is a small transfer cohort, not a powered broad closed-loop benchmark.
Targets follow the fixed synthetic maximum-displacement rule over 16 independent
reference chunks, generated before CEM; eight safe equivalent photos define the
fixed prototype. No target is accepted based on an optimizer's cost or outcome.
Each replan uses one newly observed frame and predicts one five-control model
step. This is three real replans, not a three-step imagined planning horizon.

Each arm runs a separate continuously evolving simulator through three chunks/
15 controls. Only the initial state is reset. Full measured agent/block dynamic
body state and per-control reported state, proprioception, action, contact count
and raster hashes are saved. Initial frame/proprio/full body state and first CEM
streams match before any action; later observed contexts can diverge. Returned
imagined costs across arms at later replans therefore do not share the same
context and are not directly comparable counterfactual decisions. Engineering replays
both complete 15-control sequences from initial states, never terminal 7D resets.

Each task executes six independent 130-query CEM streams: 390/arm, 780 actual,
15,600 over confirmation. There is no shared-computation claim. Every updated
mean is explicitly scored; actual selected costs/actions are certified. The
retired engineering adds six rescore queries and 30 physical replay controls only.
An earlier startup attempt failed on a JSON-string-versus-Path validation bug
before confirmation output creation or model loading. The one-line Path cast
and its regression test were applied before any confirmation outcome. The
complete first attempt, freeze, exact pre-fix source/test snapshots and startup
trace are preserved in predata_attempt1/. Repeating the same permanently retired
engineering task produced exact equality for every saved scientific array;
neither the algorithm, protocol nor task split changed. The first attempt's
77.46277731599912 seconds remain in the cumulative active budget. Its 786 candidate
queries plus 786 repeated engineering queries and 15,600 confirmation queries give
**17,172 actually executed candidate queries** across both attempts.
Active engineering+confirmation seconds: 1507.15.
The limits were 30 active minutes, 4 CPU threads, 8 GiB RSS, 500 MB new output and
06:38 UTC. Prior inputs include the completed 100-task adapter metadata receipt.

Independent same-cohort paired-task identity audit found
0 cross-task exact state/pose hashes.
Both arms and all replans are grouped as one paired task; within-task stationary
repeats are allowed and identical actions at different starts are only logged.
Exact equality does not exclude near-duplicates; unavailable original historical
raw bytes remain unavailable. Frozen scientific sources/data were not modified.

[iCEM Section3.3/AppendixE.3](https://proceedings.mlr.press/v155/pinneri21a/pinneri21a.pdf)
already uses best evaluated returns. [DINO-WM AppendixA.5](https://arxiv.org/html/2411.04983v2#A5)
already studies CEM/MPC, and [Grad+CEM](https://proceedings.mlr.press/v120/bharadhwaj20a.html)
already combines gradients/sampling. This extension tests local transfer of an
established return rule; it is not a novel optimizer or full benchmark replication.
Earlier one-step, gradient, protected-metric and adapter findings remain separate.

Portable files: summary.json, task_metadata.json, task_arrays.npz, identity_audit.json,
freeze_manifest.json, data_provenance.json, full_tests.txt (399 passing tests),
focused_tests.txt (47 passing tests), and the actually executed
../../code/notebooks/cem_closed_loop_study.ipynb. No model/simulator is needed to
read the bundle or RunAll the notebook. See export_manifest.json for execution
counts and hashes. Rebuild from complete local raw artifacts with this directory's
build_closed_loop_report.py in the project .venv, using one thread.
